# Plan de sprints — Plataforma de almuerzo corporativo

Documento vivo. Cada sprint se desarrolla y se congela solo después de tu confirmación explícita.
Los sprints 2 en adelante aparecen aquí solo como título y objetivo — se detallan uno a la vez.

**Regla de avance:** cada sprint cierra con un entregable concreto y probable por ti — no una lista de
tareas hechas, sino algo que puedes ejecutar y verificar con tus propias manos (un endpoint que responde,
una pantalla que funciona, un flujo que corre de principio a fin). No paso al siguiente sprint hasta que
confirmes explícitamente que el entregable cumple. Si algo falla en tu prueba, se corrige dentro del mismo
sprint antes de continuar.

---

## Mapa completo de sprints

| Sprint | Nombre | Objetivo | Mockup de referencia |
|---|---|---|---|
| **1** | Fundación técnica e identidad | Repo, infraestructura base, modelo de datos núcleo, autenticación y roles | — (no visual, es la base) |
| 2 | Back office: empresas y contratos | Alta de empresa, carga CSV de colaboradores, contrato con suplidores | `portal-backoffice-onboarding.html` — ✅ confirmado |
| 3 | Catálogo y menú del suplidor | Catálogo con fotos, plantilla semanal, publicación y congelamiento | `portal-suplidor-menu.html` — ✅ confirmado |
| 4 | Motor de pedidos | Elegibilidad, cutoff, cálculo de subsidio, carrito, confirmación | `mockup-plataforma-almuerzo.html` (colaborador) — ✅ confirmado |
| 5 | Entrega, disputas y política de silencio | Código de retiro, confirmación de recepción, disputa con motivo, resolución | `mockup-plataforma-almuerzo.html` (suplidor + disputa) — ✅ confirmado |
| 6 | Nómina y libro mayor | Ciclos, movimientos append-only, archivo de descuento configurable, cierre | `mockup-plataforma-almuerzo.html` (RRHH) — ✅ confirmado |
| 7 | Liquidación a suplidores | Cálculo de liquidación, modelo agente/intermediario, pago por lotes | `mockup-plataforma-almuerzo.html` (suplidor · liquidación) — ✅ confirmado |
| 8 | Sistema de ayuda y recorrido guiado | Solo el backend (API de contenido); tour visual y centro de ayuda diferidos hasta que exista un frontend | — (✅ confirmado) |
| 9 | Operación y lanzamiento | Reportes, notificaciones por email, observabilidad/endurecimiento básico, despliegue real a Render | — (✅ subsprints 9.1–9.3 confirmados; 9.4 (despliegue real) pendiente — bloqueado por falta de git) |

El orden respeta la dependencia real: no tiene sentido construir pedidos (sprint 4) antes de tener empresas y colaboradores reales (sprint 2), ni nómina (sprint 6) antes de tener pedidos que generen movimientos.

---

## Sprint 1 — Fundación técnica e identidad ✅ CONFIRMADO

**Estado: cerrado y verificado.** Construido, corrido contra Postgres real (Neon),
y confirmado por el usuario en su propia máquina (Windows + Neon) el 28 de julio
de 2026. Los tres criterios de cierre pasaron:
`npm run migrate` sin errores, `npm run smoke` (6/6), `npm run test` (5/5).

Bugs reales encontrados y corregidos durante este sprint (no cosméticos):
- Conexión de ejemplo apuntaba a un superusuario, lo que habría hecho que el
  test de RLS "pasara" sin probar nada — se separó `DATABASE_URL` (rol sin
  privilegios) de `MIGRATE_DATABASE_URL` (superusuario, solo para migraciones/seed).
- Vulnerabilidad moderada real en NestJS 10 (`npm audit`) — actualizado a NestJS 11.
- `INSERT ... SELECT ... WHERE NOT EXISTS` en el seed confundía el inferidor de
  tipos de Postgres — simplificado a dos consultas directas.
- BIGINT llega como string desde `pg`, rompía la comparación al seleccionar
  ámbito — corregido globalmente en `src/common/pg-tipos.ts`.
- El test estaba escrito para `jest` pero era un script plano — corregido a
  `node test/tenant-isolation.test.js`.
- El smoke test usaba `bash`, que no existe de forma nativa en Windows —
  reescrito en Node puro con `fetch` (`scripts/smoke-test.js`).

**Objetivo:** que exista un backend real, con base de datos, aislamiento por empresa a nivel de motor, y un sistema de login funcional — sin todavía una sola pantalla de negocio. Es el sprint menos visible y más fácil de subestimar.

**Criterio de cierre del sprint:** un desarrollador nuevo puede clonar el repo, levantar la base con `docker compose up`, correr las migraciones, crear un usuario por script, iniciar sesión vía API y recibir un JWT con sus membresías — todo sin tocar código.

---

### Subsprint 1.1 — Repositorio, infraestructura local y CI

**Tareas:**
- Monorepo NestJS con estructura de módulos: `auth`, `identidad`, `catalogo`, `pedidos`, `elegibilidad`, `finanzas`, `nomina`, `reportes` (módulos vacíos, solo el esqueleto).
- `docker-compose.yml` con PostgreSQL 16 y Redis.
- Migraciones con un ORM que soporte SQL crudo cuando haga falta (Prisma o Kysely — a decidir en esta subsprint, no antes).
- Linter, formateador y hooks de pre-commit.
- Pipeline de CI: build, lint, tests unitarios en cada push.
- Variables de entorno documentadas en `.env.example`, nunca committeadas con valores reales.

**Entregable verificable:** `docker compose up` levanta la base y el API responde `200` en un endpoint de salud (`/health`).

---

### Subsprint 1.2 — Modelo de datos núcleo y aislamiento por tenant

**Tareas:**
- Tablas: `empresa`, `usuario`, `membresia`, `colaborador`, `suplidor`, `punto_entrega`.
- Row Level Security activado sobre toda tabla con `empresa_id`, siguiendo el patrón ya validado:
  ```sql
  CREATE POLICY tenant_aislado ON <tabla>
    USING (empresa_id = current_setting('app.empresa_id')::bigint);
  ```
- Política equivalente para `suplidor_id` en las tablas que le pertenecen al suplidor — este es el pendiente que quedó marcado en la conversación de diseño y se cierra aquí, no después.
- Interceptor de NestJS que ejecuta `SET LOCAL app.empresa_id` / `app.suplidor_id` al inicio de cada transacción según el token.
- Extensión `btree_gist` habilitada, para la restricción de vigencias no solapadas que usará `asignacion_programa` más adelante.
- Semilla de datos (`seed`) con las mismas empresas, colaboradores y suplidores que ya existen en los mockups — así el backend real y los prototipos hablan de las mismas personas cuando los comparemos.

**Entregable verificable:** un test de integración que crea dos empresas, inserta datos en ambas, y demuestra que una consulta con `app.empresa_id` fijado en la empresa A nunca devuelve filas de la empresa B — ni con un `SELECT *` sin `WHERE`.

---

### Subsprint 1.3 — Autenticación, membresías y roles

**Tareas:**
- Registro y login con correo/teléfono + contraseña, hash con Argon2.
- Emisión de JWT de corta duración + refresh token.
- El JWT incluye `usuario_id` y la lista de membresías (`ambito_tipo`, `ambito_id`, `rol`).
- Endpoint para "entrar a un ámbito": si el usuario tiene más de una membresía (ej. RRHH de dos empresas), elige con cuál sesión trabaja; ese valor alimenta el interceptor de RLS de la subsprint 1.2.
- Roles mínimos implementados: `SUPERADMIN`, `SOPORTE`, `ADMIN_EMPRESA`, `RRHH`, `COLABORADOR`, `SUPLIDOR_ADMIN`, `DESPACHO`.
- Guard de autorización por rol + ámbito, reusable en cualquier endpoint futuro.
- OTP por correo o SMS como alternativa de login — no reemplaza la contraseña en este sprint, pero se deja el modelo de datos listo (tabla `otp_codigo`) para no tener que migrar después. Ya identificamos el login roto como el problema #1 de la competencia; vale la pena no dejarlo para el final.

**Entregable verificable:** un usuario con dos membresías (RRHH en empresa A, colaborador en empresa B) puede autenticarse una sola vez y elegir el ámbito; las llamadas subsecuentes a la API quedan correctamente aisladas según el ámbito elegido.

---

### Fuera de alcance de este sprint (a propósito)

- Cualquier pantalla de negocio (catálogo, pedidos, nómina) — eso empieza en el sprint 2.
- Notificaciones push — no hay nada que notificar todavía.
- Integración bancaria o de pagos — corresponde al sprint 7.
- Multi-beneficio real — el campo `tipo` en `programa_beneficio` se agrega en el sprint donde se cree esa tabla (sprint 4), no aquí.

---

## Sprint 2 — Back office: empresas, colaboradores y contratos ✅ CONFIRMADO

**Estado: cerrado y verificado.** Construido, corrido contra Postgres real (Neon),
y confirmado por el usuario en su propia máquina el 28 de julio de 2026.
Nota de proceso: este sprint se construyó antes de documentar su desglose aquí
— se corrige el orden a partir de ahora; esta sección se escribió después,
reflejando con exactitud lo que se construyó y probó, no un plan idealizado.

**Objetivo:** que exista una forma real (vía API) de dar de alta empresas,
cargar sus colaboradores desde un CSV con validación fila por fila, y
gestionar qué suplidores le sirven a cada una con qué ajuste de precio —
el equivalente en backend de `portal-backoffice-onboarding.html`.

**Criterio de cierre:** `npm run migrate` aplica la migración 4 sin errores,
y `node test/back-office.test.js` pasa sus 8 verificaciones contra la base real.

### Subsprint 2.1 — El rol de plataforma

El back office es intrínsecamente cruza-empresas: quien lo usa necesita ver
todas las empresas, no una sola — exactamente lo opuesto de lo que RRHH o un
colaborador necesitan. Eso no se resuelve reutilizando `almuerzo_app` (que
por diseño no ve nada sin un `empresa_id` fijado), sino con un segundo rol,
`almuerzo_platform`, que sí tiene `BYPASSRLS` — pero nada más: ni `CREATEROLE`,
ni `CREATEDB`, ni superusuario. Su uso queda restringido en código a requests
cuyo JWT ya pasó por `RolesGuard` con rol `SUPERADMIN` o `SOPORTE` en ámbito
`PLATAFORMA`. El interceptor de tenant ahora elige el pool correcto según el
ámbito del token, no solo el GUC.

### Subsprint 2.2 — Alta de empresa y carga de colaboradores

Endpoints `POST /back-office/empresas` y `GET /back-office/empresas`. La carga
de colaboradores soporta las dos formas de envío que se definieron para este
sprint — archivo real (`multipart/form-data`) y texto plano
(`{ "csv": "..." }`) — con un flujo de dos pasos: `preview` (valida, no escribe
nada) e `importar` (inserta solo las filas sin error). Las reglas de validación
son las mismas que se probaron visualmente en el mockup: código de nómina y
cédula obligatorios y únicos dentro del archivo, cédula con formato válido,
nombre obligatorio, y punto de entrega desconocido como **alerta**, no error.

### Subsprint 2.3 — Contratos con suplidores

Tabla `contrato_suplidor`, con RLS por empresa (para cuando RRHH necesite
consultar sus propios contratos más adelante) y gestión completa desde el
back office: crear, editar el ajuste de precio, activar/desactivar.

### Bugs reales encontrados y corregidos durante este sprint

- **Índice único que no evitaba duplicados.** La `UNIQUE` de `membresia`
  incluye `ambito_id`, que es `NULL` para membresías de ámbito `PLATAFORMA`
  — y Postgres trata cada `NULL` como distinto de cualquier otro en un índice
  único, así que `ON CONFLICT` nunca disparaba. Cada re-siembra habría creado
  una membresía de `SUPERADMIN` duplicada. Se corrigió con un índice único
  parcial (`WHERE ambito_tipo = 'PLATAFORMA'`) y se confirmó corriendo el seed
  dos veces seguidas sin duplicar.
- **Multer 1.x deprecado por vulnerabilidades reales, parchadas en 2.x.**
  Detectado por el propio warning de `npm install` en la máquina del usuario
  (no apareció en el sandbox de desarrollo). Se verificó que NestJS 11 no
  declara una versión de multer como peer dependency, se actualizó a `2.2.0`,
  y se re-verificó el flujo completo de subida de archivo — funciona idéntico.
- **`package.json` editado en el entorno de desarrollo no llegó al usuario**
  en un primer intento — quedó como recordatorio de proceso: cualquier cambio
  de dependencias debe entregarse como proyecto completo para descargar, no
  como una instrucción de "cambia esta línea", para evitar desincronización.

### Fuera de alcance de este sprint (a propósito)

Ninguna pantalla — son solo endpoints. El portal visual del back office se
construye cuando el proyecto tenga un frontend, que no es parte de estos
sprints de backend.

---

## Sprint 3 — Catálogo y menú del suplidor ✅ CONFIRMADO

**Estado: cerrado y verificado.** Construido, corrido contra Postgres real
(Neon), y confirmado por el usuario en su propia máquina el 29 de julio de
2026 — las 12 pruebas de `test/catalogo.test.js` en verde, incluida la de
fuga de RLS por `suplidor_id`. A diferencia de los sprints anteriores, no
apareció ningún bug real durante la construcción de este — el único ajuste
fue de diseño consciente, no una corrección: se decidió calcular
PUBLICADO/CONGELADO al vuelo contra el reloj real en vez de guardarlo en una
columna, evitando que dependiera de un job en segundo plano para no
desincronizarse.

**Objetivo:** que el suplidor pueda mantener su catálogo de platos, definir una
plantilla semanal de rotación, y publicar el menú de los próximos días — que
se congele automáticamente al vencer el cutoff de cada fecha. Backend real de
`portal-suplidor-menu.html`.

**Criterio de cierre:** un test de integración confirma que (a) publicar
genera `menu_dia` solo para fechas hábiles futuras según la plantilla correcta
por semana de rotación, (b) un día se congela solo después de vencer su
cutoff, y (c) el rol `SUPLIDOR_ADMIN` de un suplidor no puede ver ni tocar el
catálogo de otro — RLS por `suplidor_id`, el pendiente que quedó marcado desde
la conversación de diseño original.

### Subsprint 3.1 — Catálogo y ruta de servicio

Tablas `producto` (con `etiquetas` en JSONB para alérgenos/dietas, como se
definió en el diseño) y `ruta_servicio` (qué suplidor sirve a qué punto de
entrega, con su hora de cutoff y días de anticipación). RLS por `suplidor_id`
en ambas, reutilizando el mismo pool `almuerzo_app` y el mismo interceptor del
Sprint 1 — no hace falta un tercer rol de base de datos, porque el interceptor
ya sabía fijar `app.suplidor_id` desde que se escribió, solo que hasta ahora
ninguna tabla lo usaba.

### Subsprint 3.2 — Plantilla semanal

Tablas `plantilla_menu` y `plantilla_item` (día de la semana → productos con
precio y cupo). Se denormaliza `suplidor_id` también en `plantilla_item` — es
redundante con el que ya tiene `plantilla_menu`, pero evita que la política de
RLS dependa de un `EXISTS` con subconsulta, a cambio de mantener ese campo
sincronizado en cada insert. Decisión documentada, no accidental.

### Subsprint 3.3 — Publicación y congelamiento de `menu_dia`

El motor que aplica la plantilla a las próximas fechas hábiles, respetando la
rotación de semana (par/impar, por número de semana ISO — igual que en el
mockup) y el cutoff de cada `ruta_servicio`. Un día pasa de `PUBLICADO` a
`CONGELADO` automáticamente al vencer su cutoff; a partir de ahí, precio y
cupo dejan de poder editarse.

### Fuera de alcance de este sprint (a propósito)

- Fotos reales (CDN, recorte, tamaños) — `producto.imagen_url` queda como un
  campo de texto simple por ahora; la subida real de imágenes es trabajo de
  infraestructura de archivos que no aporta a validar la lógica de negocio.
- Aprobación del menú por la empresa (`EN_REVISION`) — mencionado como
  configurable en el diseño original, pero no se construye hasta que haya un
  cliente real que lo pida.
- Que el colaborador o RRHH vean este menú — eso es el Sprint 4 (motor de
  pedidos), que consume estas tablas pero desde el lado de la empresa.

---

## Sprint 4 — Motor de pedidos ✅ CONFIRMADO

**Estado: cerrado y verificado.** Construido y probado desde su momento
original; nunca se confirmó explícitamente por sí solo, pero se ejercitó de
punta a punta indirectamente a través de los Sprints 5, 6 y 7 (que dependen
de él) — el usuario lo confirmó formalmente el 30 de julio de 2026, junto
con la construcción del endpoint de descubrimiento de menú (ver más abajo).

**Objetivo:** que un colaborador pueda pedir su almuerzo del menú ya publicado
por el suplidor (Sprint 3), con el motor de elegibilidad completo — cutoff,
cupo, subsidio, topes — y que quede rechazado con un mensaje claro cuando
corresponda. Backend real de la vista Colaborador de `mockup-plataforma-almuerzo.html`.

**Decisión de secuencia, resuelta antes de construir:** el tope de ciclo del
colaborador necesita saber cuánto ha consumido, pero el libro mayor formal
(`movimiento`, `ciclo_nomina`) es el Sprint 6 — no puede adelantarse sin romper
el orden que ya definimos (nómina depende de pedidos ya resueltos, no al
revés). Para este sprint, el consumo del período se calcula sumando
directamente `monto_colaborador` de los pedidos activos del colaborador cuya
`fecha_servicio` cae en el período actual (calculado por fecha, según la
`frecuencia_nomina` de la empresa) — sin tabla de ciclo todavía. El Sprint 6
introduce el libro mayor formal, que en ese momento reconcilia este cálculo
ad-hoc con asientos inmutables reales.

**Criterio de cierre:** un test de integración confirma que el motor de
elegibilidad bloquea cada caso de la tabla de reglas original (cutoff vencido,
cupo agotado, tope diario, tope de ciclo, límite de endeudamiento, pedido
duplicado), y que un pedido válido calcula el desglose de subsidio
correctamente.

### Subsprint 4.1 — Programa de beneficio y asignación

Tablas `programa_beneficio` (con el campo `tipo` desde el día uno, per la
decisión de extensibilidad multi-beneficio ya tomada) y `asignacion_programa`,
con la restricción `EXCLUDE` vía `btree_gist` para que un colaborador no tenga
dos programas vigentes solapados — la misma que se documentó en el diseño
original. RLS por `empresa_id` en ambas.

### Subsprint 4.2 — Motor de elegibilidad

Puerto directo de las 6 validaciones de la sección 3.2 del documento de diseño
original, como funciones puras donde es posible (cálculo de subsidio, chequeo
de tope) y con acceso a datos donde hace falta (cupo, duplicados). La creación
del pedido corre dentro de una transacción con `SELECT ... FOR UPDATE` sobre
`menu_dia`, para que dos colaboradores no puedan tomar el mismo último cupo a
la vez — la condición de carrera que ya identificamos como riesgo en el
diseño original.

### Subsprint 4.3 — Endpoints del colaborador

Crear pedido, cancelar (antes del cutoff), y listar "mis pedidos" — ámbito
EMPRESA, rol COLABORADOR. A diferencia de RRHH (que ve todos los pedidos de
su empresa vía RLS), un colaborador solo debe ver los suyos — eso RLS no lo
distingue por rol, así que se refuerza en la capa de aplicación con un filtro
adicional por su propio `colaborador_id`.

### Fuera de alcance de este sprint (a propósito)

- Confirmación de entrega, disputas, política de silencio — Sprint 5.
- El libro mayor y el cierre de ciclo — Sprint 6, como se explicó arriba.
- Que el suplidor vea la lista de preparación derivada de estos pedidos — Sprint 5.

### Bug de arquitectura real, encontrado al probar el flujo completo

Un colaborador pide bajo ámbito `EMPRESA` — su transacción nunca fija
`app.suplidor_id`. La política de RLS del Sprint 3 (aislamiento por suplidor)
bloqueaba por completo la lectura del menú para **cualquier** colaborador de
**cualquier** empresa: RLS falla cerrado, así que sin `app.suplidor_id`
fijado, ninguna fila era visible. La migración 7 agrega políticas permisivas
adicionales — Postgres las combina con `OR` cuando son del mismo tipo — que
habilitan lectura, y el descuento de cupo, únicamente para empresas con un
`contrato_suplidor` **activo** con ese suplidor. Sin contrato, sigue sin ver
nada. Se documentó también la limitación honesta: la política de `UPDATE`
sobre `menu_dia` no restringe a nivel de base de datos qué columna se toca
(podría, en teoría, alterar precio en vez de solo cupo) — eso lo garantiza que
el código de la aplicación arme un único `UPDATE` fijo, igual que en el resto
del sistema.

### Segundo bug real, encontrado el 29 de julio de 2026 al diseñar el Sprint 7

`contrato_suplidor.ajuste_pct` existe desde el Sprint 2 (rango ±25%, pensado
para el ajuste de precio negociado entre una empresa y un suplidor
específicos) pero **nunca se aplicó en ningún cálculo** — `crearPedido`
siempre usó `menu_dia.precio` tal cual, sin tocar el contrato. Confirmado
con el usuario al diseñar el Sprint 7: un `ajuste_pct` negativo es un
descuento por volumen que el suplidor le dio a esa empresa (el colaborador
paga el precio del menú con ese % de menos que el precio publicado; 0% =
precio exacto publicado, sin ajuste). Se corrige aquí — `crearPedido` ahora
consulta `contrato_suplidor.ajuste_pct` (empresa↔suplidor del pedido) y lo
aplica a cada línea antes de calcular `bruto`. Pedidos ya creados **no** se
recalculan retroactivamente (`RECIBIDO` es terminal e inmutable por diseño;
tocar datos ya escritos en un proyecto sin ese hábito sería más riesgoso que
útil) — el fix aplica hacia adelante, a pedidos nuevos.

---

## Sprint 5 — Entrega, disputas y política de silencio ✅ CONFIRMADO

**Estado: cerrado y verificado.** Construido, corrido contra Postgres real
(Neon) incluido un flujo end-to-end real vía HTTP contra la API corriendo,
y confirmado por el usuario en su propia máquina el 29 de julio de 2026.

**Objetivo:** que el pedido avance desde `CONFIRMADO` hasta `RECIBIDO` (o
`DISPUTA`) reflejando lo que pasa en la vida real: el suplidor prepara y
entrega, el colaborador confirma o reclama, y si nadie confirma a tiempo, la
política de silencio de la empresa decide qué pasa. Backend real de la vista
Suplidor (lista de preparación) y del flujo de disputa con motivo de
`mockup-plataforma-almuerzo.html`.

**Principio heredado del Sprint 3, aplicado aquí de nuevo:** ninguna
transición se guarda por un job en segundo plano. `CONFIRMADO → EN_PREPARACION`
(al vencer el cutoff) y la política de silencio (`ENTREGADO → RECIBIDO` o
`ENTREGADO → DISPUTA`, al vencer la ventana de confirmación) se aplican de
forma perezosa: se calculan y persisten la primera vez que un endpoint
relevante toca esos pedidos, no por un cron. Esto mantiene la misma filosofía
de `menu_dia` — ver Sprint 3 — en vez de introducir infraestructura de
scheduling que este proyecto todavía no necesita.

**Criterio de cierre:** un test de integración confirma las cinco
transiciones de estado (`CONFIRMADO→EN_PREPARACION→ENTREGADO→RECIBIDO`, y la
rama `ENTREGADO→DISPUTA`), que la política de silencio configurable por
programa produce el resultado correcto en cada modo, y que un suplidor no
puede tocar pedidos de una empresa con la que no tiene contrato activo — el
mismo patrón de RLS cruzado del Sprint 4, ahora en la dirección contraria.

### Subsprint 5.1 — Configuración de política de silencio

Se agrega `politica_silencio` (`AUTO_CONFIRMA` | `AUTO_DISPUTA`) y
`horas_ventana_confirmacion` a `programa_beneficio` — es una regla del
beneficio, no una tabla nueva. Función pura para calcular si una ventana ya
venció, junto a las de `calendario.util.ts`.

### Subsprint 5.2 — RLS cruzado en la dirección del suplidor

El Sprint 4 resolvió que una empresa contratada pueda leer el menú de su
suplidor. Este sprint necesita lo inverso: que un suplidor pueda **escribir**
sobre pedidos que pertenecen a la tabla `pedido` (aislada por `empresa_id`),
para marcarlos `ENTREGADO`. Mismo mecanismo que `migrations/0007`: una
política permisiva adicional en `pedido`, condicionada a que exista un
`contrato_suplidor` activo entre el `suplidor_id` del pedido y la
`empresa_id` dueña de la fila.

### Subsprint 5.3 — Endpoints del suplidor: lista de preparación y escaneo

`GET /pedidos/preparacion` (agrupado por punto de entrega, con el consolidado
de platos a cocinar — igual que en el mockup) y `PATCH /pedidos/:id/entregar`
(valida el `codigo_retiro`, marca `ENTREGADO` con marca de tiempo).

### Subsprint 5.4 — Endpoints del colaborador: confirmar y disputar

`PATCH /pedidos/:id/confirmar-recibido` y `PATCH /pedidos/:id/disputar`, con
los mismos 5 motivos que se definieron en el mockup (`NO_LLEGO`,
`INCOMPLETO`, `EQUIVOCADO`, `CALIDAD`, `OTRO`) más nota opcional.

### Subsprint 5.5 — Resolución de disputas (RRHH)

`GET /pedidos/disputas` y `PATCH /pedidos/:id/resolver-disputa`
(`aFavorColaborador: boolean`). A favor del colaborador → `NO_ENTREGADO`
(sin cargo — el Sprint 6 decide qué hacer si el ciclo ya cerró). A favor del
suplidor → vuelve a `RECIBIDO`.

### Fuera de alcance de este sprint (a propósito)

- El cargo real en el libro mayor cuando un pedido llega a `RECIBIDO` —
  Sprint 6. Este sprint solo deja el pedido en el estado correcto; de dónde
  sale el descuento de nómina se resuelve cuando exista el libro mayor.
- Notificaciones push al colaborador ("tu pedido está en camino", "confirma
  tu entrega") — Sprint 9 (Operación).

### Notas de implementación, resueltas antes de escribir código

Puntos que esta sección no fijaba del todo y se resuelven aquí para no
dejarlos implícitos:

- **`pedido` no guarda hoy `programa_id`.** Sin eso, no hay forma de saber
  qué `politica_silencio`/`horas_ventana_confirmacion` aplican a un pedido ya
  entregado (la `asignacion_programa` del colaborador puede cambiar después).
  Se agrega `pedido.programa_id` en la migración 8, fijado en `POST /pedidos`
  igual que `subsidio_empresa`/`monto_colaborador` — un valor que se congela
  al crear el pedido, no que se recalcula después.
- **Resolución perezosa = un solo `UPDATE ... FROM ... WHERE` por request**,
  no un loop en JS por pedido. Se ejecuta al inicio de cualquier endpoint que
  liste o toque pedidos (`GET /pedidos/mios`, `GET /pedidos`, `GET
  /pedidos/disputas`, `GET /pedidos/preparacion`, y antes de
  `confirmar-recibido`/`disputar`/`resolver-disputa`), acotado por RLS de la
  misma transacción — así nunca hace falta decidir "cuál" endpoint es el que
  dispara la resolución, todos la disparan igual.
- **RLS del suplidor sobre `pedido`/`pedido_linea`:** predicado exacto —
  `suplidor_id` de la fila = GUC `app.suplidor_id` **y** existe
  `contrato_suplidor` activo entre ese suplidor y la `empresa_id` de la fila
  (no alcanza con el `suplidor_id` de la fila solo, porque una tabla sin ese
  segundo chequeo permitiría escribir en pedidos de una empresa cuyo contrato
  ya se desactivó después de creado el pedido).
- **`PATCH /pedidos/:id/no-entregado`** (suplidor marca que el colaborador no
  se presentó): no estaba listado explícitamente arriba, pero el `CHECK` de
  `estado` ya incluye `NO_ENTREGADO` desde el Sprint 4 y quedaría un estado
  del enum sin ningún camino que lo alcance si no se agrega. Libera el cupo
  de `menu_dia`, igual que `cancelar`.
- **Ventana de silencio, mecánica exacta:** `entregado_en + horas_ventana_confirmacion
  horas <= ahora()` — aritmética simple sobre timestamp, no días hábiles (a
  diferencia del cutoff de pedidos). Función pura `ventanaSilencioVencida` en
  `calendario.util.ts`, usada también para mostrarle al colaborador cuánto
  le queda en `GET /pedidos/mios`.

### Bug real encontrado y corregido durante este sprint

Las políticas nuevas de `pedido`/`pedido_linea` (migración 8) usan un
`EXISTS` contra `contrato_suplidor` para confirmar que el suplidor tiene
contrato activo con la empresa dueña del pedido — mismo mecanismo que
`migrations/0007`. Pero a diferencia de 0007 (cuyo `EXISTS` corre siempre
desde ámbito EMPRESA), aquí corre desde ámbito **SUPLIDOR** — y
`contrato_suplidor` tenía RLS que solo permitía verlo en ámbito EMPRESA
(`contrato_suplidor_por_empresa`, Sprint 2). Resultado real observado
corriendo `test/entrega-disputas.test.js`: un suplidor con contrato activo
de verdad no veía sus propios pedidos, porque el `EXISTS` evaluaba `false`
para él — no porque el contrato no existiera, sino porque RLS se lo escondía
incluso dentro de la subconsulta de otra política. Corregido en
`migrations/0009`: una política adicional que deja al suplidor ver sus
propios contratos (con cualquier empresa), simétrica a la que ya tenía la
empresa.

### Nota de alcance para un sprint futuro — ✅ resuelto el 30 de julio de 2026

Al armar la verificación end-to-end de este sprint quedó expuesto un hueco
que ya existía desde el Sprint 3/4, no introducido por este: `GET
/catalogo/menu` es un endpoint de ámbito `SUPLIDOR_ADMIN` únicamente, y no
devuelve `suplidor_id` en cada item. Un colaborador real no tenía ninguna
forma de descubrir vía API qué suplidores y qué `menuDiaId` puede pedir —
`POST /pedidos` exige `suplidorId` que el cliente ya debía conocer de
antemano. En este sprint y en el 4 esto se resolvió consultando la base
directamente durante las pruebas — quedó anotado para retomar, sin resolver
en su momento para no ampliar el alcance de "entrega, disputas y silencio".

**Resuelto al cerrar el roadmap actual (Sprint 9):** `GET
/pedidos/menu-disponible?desde=&hasta=` (COLABORADOR) — solo suplidores con
ruta activa al punto de entrega del colaborador **y** contrato activo con
su empresa (las mismas dos condiciones que ya exige `crearPedido`), con el
precio ya ajustado por `ajuste_pct` (Sprint 7, lo que de verdad pagaría) y
si todavía se puede pedir (`disponible`, antes del cutoff, con cupo).
Verificado end-to-end: se usó la respuesta de este endpoint, sin ninguna
consulta manual a la base, para armar un `POST /pedidos` real y exitoso.

**Criterio de cierre, verificado:**
1. `npm run migrate` aplicó las migraciones 8 y 9 sin errores sobre la base
   real (Neon).
2. `node test/entrega-disputas.test.js` — 10/10 verificaciones en verde:
   funciones puras de ventana de silencio, RLS nueva del suplidor sobre
   `pedido`/`pedido_linea` (con y sin contrato), y resolución perezosa por
   silencio en sus dos modos (`AUTO_CONFIRMA` y `AUTO_DISPUTA`).
3. Suite completa de sprints anteriores (`tenant-isolation`, `back-office`,
   `catalogo`, `pedidos`) sigue en verde — sin regresiones.
4. Flujo completo end-to-end contra la API real corriendo (`npm run build &&
   npm run start`, sin mocks): publicar menú → crear pedido (colaborador) →
   ver lista de preparación sin el código expuesto → preparar → entregar con
   código incorrecto (rechazado) → entregar con código correcto → el
   colaborador ve `puedeConfirmar`/`ventanaConfirmacionVenceEn` → disputar →
   RRHH ve la disputa → resolver a favor del colaborador → cupo liberado.
5. **Falta:** confirmación explícita del usuario en su propia máquina.

---

## Sprint 6 — Nómina y libro mayor ✅ CONFIRMADO

**Estado: cerrado y verificado.** Construido, corrido contra Postgres real
(Neon) incluido un flujo end-to-end real vía HTTP contra la API corriendo,
y confirmado por el usuario en su propia máquina el 29 de julio de 2026.

**Objetivo:** que exista un registro formal, inmutable, de cuánto le
corresponde descontar a cada colaborador — y que RRHH pueda cerrar un ciclo
de nómina y descargar el archivo que alimenta la nómina real de la empresa,
con las columnas que esa empresa necesite. Backend real de la vista RRHH de
`mockup-plataforma-almuerzo.html`.

**Decisiones de producto, resueltas con el usuario antes de construir (no
hay mockup para esta parte en este repo):**
1. **El cargo se genera cuando el pedido llega a `RECIBIDO`** — sin importar
   si fue por confirmación del colaborador, por silencio, o porque RRHH
   resolvió una disputa a favor del suplidor (Sprint 5). Antes de eso no hay
   movimiento; `CANCELADO` y `NO_ENTREGADO` nunca generan cargo.
2. **Cierre de ciclo bloqueado por defecto si quedan pedidos sin resolver**
   (`ENTREGADO`/`DISPUTA`) dentro de su rango de fechas — evita tener que
   mover cargos entre ciclos en el caso común. Es configurable por empresa
   (`empresa.permite_cierre_con_pendientes`, default `false`): si una
   empresa la activa, puede cerrar igual, y cualquier pedido pendiente que
   se resuelva después postea su cargo en el ciclo abierto **en ese
   momento**, nunca en el que ya cerró — el libro mayor es append-only, jamás
   se reabre ni se edita un ciclo cerrado.
3. **Cierra RRHH/ADMIN_EMPRESA de la propia empresa** — mismo rol que ya
   administra pedidos y disputas (Sprint 4/5).
4. **Archivo de descuento configurable por empresa**, no un CSV de forma
   fija: cada empresa elige qué columnas quiere y en qué orden, de un
   catálogo fijo de campos disponibles (no fórmulas ni SQL libre, por
   seguridad) — ver subsprint 6.4.

**Reconciliación con el Sprint 4 (decisión técnica, no de producto):** el
tope de ciclo que ya corre en `POST /pedidos` (`crearPedido`) sigue sumando
`monto_colaborador` de pedidos **no cancelados/no-entregados**, sin importar
si ya llegaron a `RECIBIDO` — a propósito. Ese chequeo existe para frenar al
colaborador mientras el pedido todavía está en camino, así que necesita
contar también lo que aún no se ha confirmado como recibido (si solo
contara `movimiento`, un colaborador podría acumular pedidos sin límite
mientras ninguno llegue a `RECIBIDO` todavía). El libro mayor (`movimiento`)
es la fuente de verdad de lo que realmente se descuenta; el chequeo de
`crearPedido` sigue siendo un freno preventivo en tiempo real, con un
propósito distinto. No se tocan las queries del Sprint 4/5.

**Criterio de cierre, verificado:**
1. `npm run migrate` aplicó la migración 10 sin errores sobre la base real
   (Neon), incluido el `REVOKE UPDATE, DELETE ON movimiento FROM
   almuerzo_app`.
2. `node test/nomina.test.js` — 17/17 verificaciones en verde: catálogo y
   generador de CSV puros, `almuerzo_app` rechazado con `insufficient_privilege`
   al intentar `UPDATE`/`DELETE` sobre `movimiento`, `postearCargo` crea y
   reutiliza el ciclo correcto, no postea nada con monto 0 (cobertura
   total), y un cargo cuyo período original ya cerró se postea en el ciclo
   abierto vigente hoy sin tocar el cerrado.
3. Suite completa de sprints anteriores sigue en verde — sin regresiones.
4. Flujo end-to-end contra la API real corriendo: colaborador pide y
   confirma un pedido → se postea un `CARGO` automático por el monto
   correcto → un segundo pedido queda `ENTREGADO` sin resolver en el mismo
   período → `POST /nomina/ciclos/cerrar` se bloquea (403) → se resuelve
   (el colaborador lo confirma) → el cierre procede → cerrar de nuevo el
   mismo ciclo se rechaza (no reabre) → `PUT /nomina/plantilla-descuento`
   guarda una plantilla propia (rechaza un campo fuera del catálogo) →
   `GET /nomina/ciclos/:id/archivo-descuento` devuelve un CSV con
   exactamente esas columnas, en ese orden, con la etiqueta personalizada
   bien escapada → `POST /nomina/movimientos/ajuste` (nota de crédito)
   postea en el ciclo abierto vigente, no en el que ya cerró.
5. **Falta:** confirmación explícita del usuario en su propia máquina.

### Subsprint 6.1 — Libro mayor (`movimiento`), append-only

Tabla `movimiento`: `id`, `empresa_id`, `colaborador_id`, `ciclo_nomina_id`,
`pedido_id` (nullable — una corrección manual puede no estar atada a un
pedido), `tipo` (`CARGO` | `NOTA_CREDITO` — sin un tercer tipo "AJUSTE": un
ajuste manual ya ES un `CARGO` o una `NOTA_CREDITO` sin `pedido_id`, un
tercer tipo obligaría a otro campo para saber el signo), `monto` (siempre
positivo; el signo lo da `tipo`, no un negativo escondido), `motivo`,
`creado_en`, `creado_por` (nullable — `NULL` cuando el sistema lo genera
automáticamente, ej. al llegar a `RECIBIDO`). Sin `UPDATE` ni `DELETE`
posible ni siquiera a nivel de permisos de Postgres (`REVOKE UPDATE, DELETE
... FROM almuerzo_app`) — la única forma de corregir un monto es una fila
nueva que lo compense.

El `CARGO` se genera automáticamente: en los mismos puntos donde Sprint 5
hace `estado = 'RECIBIDO'` (confirmación del colaborador, resolución
perezosa por silencio, y resolución de disputa a favor del suplidor), se
inserta el movimiento dentro de la misma transacción — si el `UPDATE` del
pedido falla, el `movimiento` tampoco se crea.

### Subsprint 6.2 — Ciclos de nómina (`ciclo_nomina`)

Tabla `ciclo_nomina`: `id`, `empresa_id`, `periodo_inicio`, `periodo_fin`,
`estado` (`ABIERTO` | `CERRADO`), `cerrado_en`, `cerrado_por`. `UNIQUE
(empresa_id, periodo_inicio, periodo_fin)`. Se crea de forma perezosa —
"buscar o crear" el ciclo `ABIERTO` correspondiente la primera vez que un
`movimiento` necesita postear en ese período (reutilizando `periodoDe()` de
`calendario.util.ts`, ya escrito en el Sprint 4) — ningún cron pre-crea
ciclos por adelantado, mismo principio de todo este proyecto.

`ALTER TABLE empresa ADD COLUMN permite_cierre_con_pendientes BOOLEAN NOT
NULL DEFAULT false` — la bandera de la decisión 2.

### Subsprint 6.3 — Cierre de ciclo y correcciones posteriores

`POST /nomina/ciclos/cerrar` (`{ periodoInicio, periodoFin }` o el ciclo
`ABIERTO` vigente por defecto) — valida que no haya pedidos
`ENTREGADO`/`DISPUTA` en el rango salvo que
`empresa.permite_cierre_con_pendientes` sea `true`; si pasa, marca
`estado = 'CERRADO'`, `cerrado_en`, `cerrado_por`.

`POST /nomina/movimientos/ajuste` (RRHH) — `{ colaboradorId, tipo:
'CARGO'|'NOTA_CREDITO', monto, motivo }`. Postea siempre contra el ciclo
`ABIERTO` vigente en el momento de la corrección, nunca contra uno ya
cerrado — es el mecanismo para toda corrección administrativa posterior
(disputa tardía, error de digitación, lo que sea), sin tocar jamás una fila
existente.

### Subsprint 6.4 — Archivo de descuento configurable

Catálogo fijo de campos disponibles (no hay expresiones libres, por
seguridad): `codigo_nomina`, `cedula`, `nombre_completo`, `punto_entrega`,
`cantidad_pedidos`, `monto_total`, `subsidio_total_empresa`,
`periodo_inicio`, `periodo_fin`. Una plantilla activa por empresa
(`plantilla_reporte_descuento`: `empresa_id`, `campos` JSONB — array
ordenado de claves del catálogo, cada una con una etiqueta de columna
opcional). Si la empresa nunca configura una, se usa una plantilla default
razonable (`codigo_nomina`, `nombre_completo`, `monto_total`).

- `GET /nomina/plantilla-descuento` / `PUT /nomina/plantilla-descuento`
  (RRHH) — ver/editar qué campos y en qué orden.
- `GET /nomina/ciclos/:id/archivo-descuento` (RRHH) — genera el CSV
  agregando `movimiento` por colaborador dentro de ese ciclo, con
  exactamente las columnas configuradas.

### Fuera de alcance de este sprint (a propósito)

- Múltiples plantillas con nombre por empresa (una activa por empresa
  alcanza para este sprint; si hace falta más adelante, es una tabla en vez
  de un registro único, cambio menor).
- Integración directa con un sistema de nómina real (ADP, sistemas locales
  dominicanos) — el archivo es un CSV para pegar a mano, no una API.
- Reapertura de un ciclo ya cerrado — a propósito nunca existe; toda
  corrección es una fila nueva (`CARGO`/`NOTA_CREDITO` manual).
- Liquidación a suplidores (cuánto se le paga a cada suplidor) — Sprint 7,
  es la mitad opuesta del dinero (lo que entra vs. lo que sale).

---

## Sprint 7 — Liquidación a suplidores ✅ CONFIRMADO

**Estado: cerrado y verificado.** Construido, corrido contra Postgres real
(Neon) incluido un flujo end-to-end real vía HTTP contra la API corriendo,
y confirmado por el usuario en su propia máquina el 30 de julio de 2026.

**Objetivo:** que la plataforma calcule cuánto le corresponde cobrar a cada
suplidor por lo que de verdad se entregó (`RECIBIDO`), agregado a través de
todas las empresas que ese suplidor sirve, en lotes por período — y que se
pueda marcar un lote como pagado una vez transferido el dinero fuera del
sistema. Backend real de la vista Suplidor · Liquidación de
`mockup-plataforma-almuerzo.html`.

**Decisiones de producto, resueltas con el usuario antes de construir (no
hay mockup para esta parte en este repo):**
1. **`ajuste_pct` ajusta lo que paga el colaborador**, no un margen
   escondido de plataforma — ver el bug real corregido arriba, bajo Sprint 4.
   El precio ya ajustado (`total_bruto` de cada `pedido`) es exactamente lo
   que se le debe al suplidor por ese pedido: no hay una comisión de
   plataforma separada en este sprint, nadie mencionó que exista una.
2. **La plataforma actúa como intermediaria**: liquida a cada suplidor
   agregando pedidos de **todas** las empresas que lo contrataron en el
   período, no una liquidación separada por cada relación empresa-suplidor.
   Coincide con el "modelo agente/intermediario" que ya estaba anotado en el
   mapa de sprints.
3. **Sin integración bancaria real**: el sistema calcula el lote y genera un
   reporte; el pago real ocurre fuera del sistema, y alguien de plataforma
   lo marca como pagado a mano (mismo patrón que el archivo de descuento
   del Sprint 6, sin credenciales bancarias de por medio).

**Decisión de implementación, resuelta sin necesidad de preguntar (patrón ya
establecido, solo trasladado):** un suplidor puede servir a empresas con
`frecuencia_nomina` distinta (quincenal vs. mensual) — agregar "por período"
no puede depender de la frecuencia de nómina de ninguna empresa en
particular. Se agrega `suplidor.frecuencia_liquidacion` (mismo dominio
`QUINCENAL`/`MENSUAL`, default `QUINCENAL`), y se reutiliza `periodoDe()` de
`calendario.util.ts` parametrizada por esa frecuencia, no la de la empresa.

**Decisión de arquitectura, para no duplicar el libro mayor del Sprint 6:**
no hace falta una tabla `movimiento_suplidor` — a diferencia del lado
colaborador (donde el silencio y las disputas hacían falta resolver antes de
que un cargo fuera definitivo), del lado suplidor un `pedido` en `RECIBIDO`
ya es terminal e inmutable por diseño (ningún endpoint transiciona un pedido
fuera de `RECIBIDO`). Por eso el mismo patrón de bloqueo del Sprint 6
(no calcular con pendientes, salvo que se permita explícitamente) alcanza
para garantizar que, al calcular un lote, todo lo relevante en ese rango ya
esté resuelto — un simple `SUM(total_bruto) FROM pedido WHERE estado =
'RECIBIDO'` en el momento del cálculo es correcto y completo, sin necesitar
rastrear "qué pedido ya se contó" en una tabla aparte.

**Criterio de cierre, verificado:**
1. `npm run migrate` aplicó la migración 11 sin errores sobre la base real
   (Neon).
2. `node test/liquidaciones.test.js` — 7/7 verificaciones en verde:
   `aplicarAjustePct` con datos fijos (descuento, recargo, 0%, redondeo a 2
   decimales), y RLS de `lote_pago_suplidor` (un suplidor ve sus propios
   lotes, no puede editarlos directamente — 0 filas afectadas por `UPDATE`,
   sin política permisiva para ese comando — y no ve los lotes de otro
   suplidor).
3. Suite completa de sprints anteriores sigue en verde — sin regresiones.
4. Flujo end-to-end contra la API real corriendo: se aplica un `ajuste_pct`
   real de -10% a un contrato → un pedido nuevo lo refleja correctamente en
   `total_bruto` → se entrega y confirma → una segunda empresa (fixture)
   contrata al mismo suplidor con un pedido `RECIBIDO` propio → calcular la
   liquidación agrega ambas empresas → se bloquea mientras queda un pedido
   `ENTREGADO` sin resolver → se resuelve → el cálculo procede con el total
   y la cantidad correctos → recalcular el mismo período se rechaza → el
   suplidor ve el lote y su desglose completo (empresa, no colaborador) →
   marcar pagado → volver a marcar pagado se rechaza.
5. **Falta:** confirmación explícita del usuario en su propia máquina.

### Bugs reales encontrados y corregidos durante la verificación end-to-end

- **RLS de `colaborador` bloqueaba el desglose de `GET
  /liquidaciones/:id` para el suplidor.** La primera versión hacía `JOIN
  colaborador` para mostrar el nombre de quien pidió — pero `colaborador`
  tiene RLS por `empresa_id` (Sprint 1), invisible en ámbito SUPLIDOR, así
  que el `JOIN` eliminaba **todas** las filas del desglose (`pedidos: []`),
  aunque `monto_total` (calculado bajo ámbito PLATAFORMA) fuera correcto.
  Mismo patrón exacto que el bug de `contrato_suplidor` del Sprint 5
  (migración 9): una tabla referenciada por `JOIN` deniega la fila completa
  si su propia RLS no la deja ver, sin importar qué tan permisiva sea la
  política de la tabla principal. Corregido reemplazando el `JOIN` por
  `empresa` (sin RLS propia) — que además es la información correcta: el
  suplidor necesita saber de qué empresa es cada pedido para su
  liquidación, no qué colaborador individual lo hizo (PII que no le
  corresponde ver).
- **Comparación de fechas rota por serialización de `Date`.**
  `periodo_inicio`/`periodo_fin` vuelven de Postgres como objetos `Date` de
  JavaScript (columna `DATE`). Pasarlos tal cual como parámetros de otra
  consulta los serializa con hora y zona horaria (ej. `2026-09-16T04:00:00.000Z`
  en vez de `2026-09-16`), desplazando el rango `BETWEEN` lo suficiente
  para excluir pedidos que sí correspondían. Corregido normalizando con
  `iso(new Date(...))`, el mismo helper que ya se usa en el resto del
  código para este propósito exacto — el bug era no haberlo aplicado aquí
  también.

### Subsprint 7.1 — Corrección de `ajuste_pct` en el motor de pedidos

`crearPedido` consulta `contrato_suplidor.ajuste_pct` (empresa↔suplidor del
pedido, ya sabemos que existe activo por construcción — RLS de 0007 no deja
ver el menú sin él) y lo aplica a cada línea antes de sumar `bruto`:
`precioAjustado = precio_base * (1 + ajuste_pct/100)`, redondeado a 2
decimales, mismo criterio de redondeo que ya usa `calcularSubsidio`.

### Subsprint 7.2 — `lote_pago_suplidor`

Tabla `lote_pago_suplidor`: `id`, `suplidor_id`, `periodo_inicio`,
`periodo_fin`, `estado` (`CALCULADO` | `PAGADO`), `monto_total`,
`cantidad_pedidos`, `calculado_en`, `calculado_por`, `pagado_en`,
`pagado_por`, `referencia_pago`. `UNIQUE (suplidor_id, periodo_inicio,
periodo_fin)`. RLS: el propio suplidor ve sus lotes (`suplidor_id =
app.suplidor_id`); plataforma los gestiona todos vía `almuerzo_platform`
(`BYPASSRLS`), igual que el back office.

`ALTER TABLE suplidor ADD COLUMN frecuencia_liquidacion` y `ADD COLUMN
permite_liquidacion_con_pendientes BOOLEAN NOT NULL DEFAULT false` — misma
bandera que `empresa.permite_cierre_con_pendientes`, ahora del lado suplidor.

### Subsprint 7.3 — Endpoints

Nuevo controlador `LiquidacionesController`, ámbito mixto (mismo patrón que
`PedidosController`: sin `@Roles` a nivel de clase, cada método declara el
suyo):
- `POST /liquidaciones/calcular` (plataforma, `SUPERADMIN`/`SOPORTE`) —
  `{ suplidorId, periodoInicio?, periodoFin? }`. Bloquea con 403 si hay
  pedidos `ENTREGADO`/`DISPUTA` de ese suplidor en el rango, salvo
  `permite_liquidacion_con_pendientes`. Calcula y persiste el lote.
- `GET /liquidaciones` (plataforma: todos; suplidor: los suyos, vía RLS) —
  lista de lotes.
- `GET /liquidaciones/:id` (mismo acceso) — detalle, con el desglose de
  pedidos que se contaron.
- `PATCH /liquidaciones/:id/marcar-pagado` (plataforma) —
  `{ referenciaPago }`. `CALCULADO` → `PAGADO`. Rechaza si ya está `PAGADO`.

**Limitación honesta:** `GET /liquidaciones/:id` incluye un desglose de los
pedidos que explican `monto_total`, recalculado en el momento de la
consulta (no se persiste). En ámbito SUPLIDOR, la RLS de `pedido` (Sprint 5)
solo deja ver pedidos de empresas con `contrato_suplidor` todavía **activo**
— si el contrato se desactivó después de la entrega, ese pedido puede faltar
en el desglose que ve el suplidor, aunque `monto_total` (calculado bajo
ámbito PLATAFORMA, que sí ve todo) siga siendo correcto. Mismo tipo de nota
de alcance que ya se documentó en `migrations/0007`.

### Fuera de alcance de este sprint (a propósito)

- Ajustes manuales sobre un lote ya calculado (bonos, penalizaciones) — si
  hace falta, es una extensión futura del mismo patrón que
  `POST /nomina/movimientos/ajuste` del Sprint 6, no se construye aquí sin
  que alguien lo pida primero.
- Integración bancaria o de pagos real — el archivo/reporte es para que
  alguien pague fuera del sistema, no una pasarela de pago.
- Recalcular retroactivamente pedidos creados antes del fix de `ajuste_pct`
  — ver la nota bajo Sprint 4.

---

## Sprint 8 — Sistema de ayuda y recorrido guiado ✅ CONFIRMADO

**Estado: cerrado y verificado.** Construido, corrido contra Postgres real
(Neon) incluido un flujo end-to-end real vía HTTP contra la API corriendo
(sin bugs encontrados), y confirmado por el usuario en su propia máquina el
30 de julio de 2026.

**Nota de alcance, resuelta con el usuario el 30 de julio de 2026, antes de
construir:** esta sección se escribió muy al inicio del proyecto, antes del
Sprint 1, y describe una feature de **frontend** — ícono contextual, tour
con overlay sobre "elementos reales de la interfaz", pantalla dedicada. Este
proyecto es puramente backend (ningún sprint construye pantallas — ver
"fuera de alcance" de los Sprints 2 y 3), y no existe ningún cliente visual
en este repo. Nunca se revisó este plan contra esa realidad hasta ahora.

**Decisión:** se construye solo el backend del contenido — la tabla
`ayuda_contenido` y los endpoints para consultarla/administrarla (subsprint
8.1, adaptado). Los subsprints 8.2 (tour con overlay) y 8.3 (pantalla
dedicada) quedan **fuera de alcance a propósito** hasta que exista un
frontend real que los consuma — no tiene sentido construir un tour contra
una interfaz que no existe. Se sembra contenido de ejemplo real (política de
silencio, tope de endeudamiento, nota de crédito tras cierre de ciclo — las
mismas reglas que ya menciona el entregable original de este sprint) para
que la API sea demostrable de verdad, no un CRUD vacío.

**Objetivo (ajustado):** que exista una API de contenido de ayuda —
consultable por cualquier rol autenticado, filtrada a lo suyo, con
buscador — y administrable por plataforma (`SUPERADMIN`/`SOPORTE`). Sienta
la base de datos y el contrato de API para que, el día que exista un
frontend, el tour y el centro de ayuda (subsprints 8.2/8.3) se construyan
consumiendo esto sin tocar el backend de nuevo.

**Criterio de cierre (ajustado), verificado:**
1. `npm run migrate` aplicó las migraciones 12 y 13 sin errores sobre la
   base real (Neon).
2. `node test/ayuda.test.js` — 10/10 verificaciones en verde: el contenido
   sembrado existe, el filtro por rol (propio + `TODOS`) funciona, el
   buscador por texto encuentra la ficha correcta, y `almuerzo_app` no
   puede escribir en `ayuda_contenido` (rechazado con `insufficient_privilege`,
   `REVOKE` de la migración 13) aunque sí puede leerlo.
3. Suite completa de sprints anteriores sigue en verde — sin regresiones.
4. Flujo end-to-end contra la API real corriendo: un colaborador ve su
   ficha de política de silencio pero no la de liquidación a suplidores; un
   suplidor ve la suya pero no la del colaborador; `?pantallaId=` y
   `?buscar=` filtran correctamente; RRHH no puede crear contenido (403);
   plataforma sí puede crear, editar (la versión sube), rechazar un
   `rolObjetivo` inválido (400), y borrar.
5. **Falta:** confirmación explícita del usuario en su propia máquina.

Sin bugs reales encontrados en este sprint — a diferencia de los anteriores,
el flujo end-to-end pasó limpio en el primer intento.

---

### Subsprint 8.1 — API de contenido de ayuda (construido)

**Tareas:**
- Tabla `ayuda_contenido`: cada ficha tiene `titulo`, `cuerpo` (markdown corto), `rol_objetivo` (uno de los
  roles existentes, o `TODOS` para contenido visible a cualquier rol), `pantalla_id` (identificador libre —
  lo definirá el frontend el día que exista; por ahora usa nombres descriptivos como `pedidos.confirmar`),
  y `orden`. Sin RLS por empresa/suplidor: es contenido de plataforma, igual para todos los que comparten rol.
- Versionado simple: `version` y `actualizado_en`, para saber si el contenido quedó desactualizado respecto
  a un cambio reciente de la regla que describe.
- `GET /ayuda` (cualquier rol autenticado) — filtra por el rol del propio usuario (`rol_objetivo` = su rol
  o `TODOS`), con `?pantallaId=` y `?buscar=` (ILIKE sobre título/cuerpo) opcionales.
- `POST /ayuda`, `PATCH /ayuda/:id`, `DELETE /ayuda/:id` (`SUPERADMIN`/`SOPORTE`, ámbito PLATAFORMA) — CRUD
  administrativo, mismo patrón que el back office.
- Semilla de contenido real: fichas explicando política de silencio, tope de endeudamiento, y nota de
  crédito tras cierre de ciclo — las mismas reglas que ya menciona el entregable original de este sprint.

**Entregable verificable:** un colaborador autenticado consulta `GET /ayuda` y recibe solo fichas de su rol
o `TODOS`; el buscador encuentra la ficha de "política de silencio" por texto; un intento de crear/editar/
borrar contenido sin ser plataforma se rechaza.

---

### Subsprint 8.2 — Recorrido guiado por rol (diferido — requiere un frontend real)

**Tareas:**
- Un tour paso a paso (tipo overlay con resaltado de elementos reales de la interfaz, no capturas de
  pantalla estáticas) para cada uno de los cuatro roles:
  - **Colaborador:** qué es el cutoff, cómo se lee el desglose de subsidio, qué significa cada estado de
    su pedido, cómo y cuándo reportar un problema.
  - **Suplidor:** diferencia entre catálogo y menú del día, cómo funciona la plantilla semanal y la
    rotación, qué significa que un día esté congelado, cómo se calcula su liquidación.
  - **RRHH:** cómo se configura el programa de beneficio, qué es el libro mayor y por qué nunca se edita,
    cómo resolver una disputa y qué implica que el ciclo ya haya cerrado.
  - **Back office:** el flujo completo de alta de empresa, qué validaciones aplica la carga de CSV y por
    qué, cómo funciona el ajuste de precio por contrato.
- El tour se activa automáticamente en el primer ingreso de cada usuario nuevo a su rol, y queda disponible
  para repetirse manualmente desde el menú en cualquier momento.
- Cada paso del tour enlaza a su ficha de `ayuda_contenido` correspondiente, para quien quiera más detalle
  del que cabe en el paso del tour.

**Entregable verificable:** los cuatro recorridos completos, probados por ti navegando cada uno de principio
a fin sin código de por medio — solo la interfaz real.

---

### Subsprint 8.3 — Centro de ayuda (diferido — requiere un frontend real)

**Tareas:**
- Una pantalla dedicada (no un modal perdido) que organiza todas las fichas de `ayuda_contenido` del rol
  activo por categoría, con el buscador de la subsprint 8.1 en la parte superior.
- Cada ficha explica no solo el "cómo" sino el "por qué" cuando la regla de negocio no es obvia — por
  ejemplo, por qué el cargo no se genera hasta que el colaborador confirma la entrega, o por qué un menú
  se congela al vencer el cutoff. Esto es exactitud, no solo cobertura: el contenido debe describir el
  comportamiento real del sistema, verificado contra el código, no una aproximación.
- Enlace visible desde cualquier pantalla del sistema hacia el centro de ayuda de ese rol.

**Entregable verificable:** localizar, desde el centro de ayuda, la explicación de cualquier regla de
negocio discutida en este documento (política de silencio, tope de endeudamiento, nota de crédito tras
cierre de ciclo) en menos de tres clics, con el texto describiendo correctamente el comportamiento actual.

---

### Fuera de alcance de este sprint (a propósito)

- Ayuda en video o soporte en vivo (chat, WhatsApp) — es un centro de ayuda estático más tour interactivo,
  no un canal de soporte humano.
- Traducción a otros idiomas — el sistema es en español, igual que toda esta conversación.
- Ayuda personalizada por IA (un asistente conversacional dentro de la app) — es una extensión posible a
  futuro, pero no de este sprint.

---

## Sprint 9 — Operación y lanzamiento — subsprints 9.1–9.3 ✅ CONFIRMADOS; 9.4 preparado, despliegue real pendiente

**Estado: 9.1–9.3 cerrados y verificados.** Construidos, corridos contra
Postgres real (Neon) incluido un flujo end-to-end real vía HTTP, y
confirmados por el usuario en su propia máquina el 30 de julio de 2026.
9.4 (despliegue real) sigue sin poder avanzar — ver el bloqueo de git más
abajo.

**Objetivo:** cerrar el roadmap actual con lo que hace falta para operar el
sistema de verdad — reportes para RRHH/plataforma, notificaciones reales
por correo, un mínimo de observabilidad/endurecimiento gratuito, y el
despliegue real a producción (Render + Neon, ya anotado como plan futuro en
`CLAUDE.md`).

**Decisiones de producto, resueltas con el usuario antes de construir** (el
roadmap original marcaba este sprint como "a definir con RRHH" — nunca se
definió hasta ahora):
1. **Despliegue real, no solo preparación.** Yo dejo el repo listo
   (`render.yaml`, variables de entorno documentadas) y te guío paso a paso;
   la creación de la cuenta en Render y la conexión real las haces tú —
   crear cuentas externas no es algo que deba hacer por mi cuenta.
2. **Notificaciones por email real**, con un proveedor de free tier
   (Resend, vía su API HTTP directa con `fetch` — sin SDK, mismo criterio
   de dependencias mínimas que ya usa el proyecto). Requiere que crees una
   cuenta gratuita y me des la API key en `.env`.
3. **Reportes**: propuestos por mí a partir de los datos que ya existen (no
   pedidos específicos del usuario) — ver subsprint 9.1.
4. **Observabilidad y endurecimiento básico y gratuito**: sin servicios de
   pago — `helmet`, rate limiting con `@nestjs/throttler` en `/auth/login`,
   logging estructurado de requests, y validación de variables de entorno
   críticas al arrancar.

**Prerrequisito descubierto, no anotado en ningún lado hasta ahora:** este
proyecto **no es un repositorio git todavía** — 8 sprints construidos sin
control de versiones. Render se conecta a un repo de GitHub para desplegar
automáticamente en cada push; sin git, ese camino no existe. Antes del
subsprint 9.4 hace falta `git init`, un primer commit, y un repo en GitHub
— se confirma con el usuario antes de tocarlo, por ser una acción que
crea infraestructura compartida nueva (regla de "acciones con cuidado").

**Criterio de cierre, verificado (subsprints 9.1–9.3):**
1. `npm run migrate` aplicó la migración 14 sin errores sobre la base real
   (Neon). `npm install helmet @nestjs/throttler` agregó 2 dependencias
   nuevas a `package.json` (ninguna vulnerabilidad propia — las 21 que
   reporta `npm audit` son preexistentes, todas de `jest`, una
   devDependency que no llega a producción; no se tocaron, es una limpieza
   aparte que no corresponde a este sprint).
2. `node test/reportes.test.js` (4/4) y `node test/notificaciones.test.js`
   (4/4) en verde. Suite completa de sprints anteriores sigue en verde —
   sin regresiones.
3. Flujo end-to-end contra la API real corriendo: los 4 reportes responden
   con datos reales y respetan RLS (`consumo-colaborador`/`gasto-empresa`
   acotados a la propia empresa en ámbito EMPRESA, agregando todas bajo
   PLATAFORMA; un colaborador no puede verlos); entregar un pedido genera
   una fila `notificacion_enviada` real (`OMITIDA`, porque la colaboradora
   de prueba no tiene email cargado en el seed — comportamiento correcto,
   no un bug); los headers de `helmet` aparecen en cualquier respuesta;
   `/auth/login` responde `401` en los primeros 5 intentos de una ventana
   de 60s y `429` en el sexto; la validación de variables de entorno falla
   rápido con el mensaje correcto cuando falta una.
4. **Falta:** confirmación explícita del usuario en su propia máquina.

**Subsprint 9.4 (despliegue real):** `render.yaml` escrito y la guía
paso a paso agregada al README. **No se ejecutó nada externo** — ver el
prerrequisito de git/GitHub abajo, pendiente de confirmación explícita
antes de tocarlo (regla de "acciones con cuidado": crear un repositorio en
GitHub y conectar una cuenta de Render es infraestructura nueva y
compartida, no una acción reversible como escribir un archivo).

**Bloqueo real encontrado al intentar cumplir el prerrequisito de git:**
el usuario confirmó que quería `git init` + GitHub, pero **git no está
instalado en esta máquina**, y el entorno de ejecución de esta sesión
bloquea la descarga de archivos binarios/ejecutables por seguridad
("body content-type denied" — tanto `winget install` como una descarga
directa del instalador de Git para Windows fallaron con 403, aunque el
acceso normal a github.com funciona bien). No se pudo instalar git desde
esta sesión.

**Decisión, con el usuario:** seguir sin git por ahora. En su lugar:
- `CHANGELOG.md` (raíz del proyecto) — historial legible por sprint, qué
  archivos cambiaron.
- `versiones/` — un `.zip` restaurable por cada sprint confirmado a partir
  de ahora (sin `node_modules`/`dist`/`.env`), con su propio `README.md`
  explicando cómo volver a una versión anterior. No fue posible reconstruir
  snapshots retroactivos de los Sprints 1–8 — el árbol de trabajo solo
  refleja el estado acumulado actual.
- El despliegue real a Render sigue bloqueado por la falta de git — cuando
  el usuario instale git por su cuenta (fuera de esta sesión, con acceso
  normal de navegador) o resuelva el bloqueo de otra forma, se retoma el
  subsprint 9.4 desde donde quedó.

### Subsprint 9.1 — Reportes

Cuatro endpoints de solo lectura, agregando sobre tablas que ya existen —
sin tablas nuevas, sin romper RLS (cada query corre en la misma transacción
con ámbito ya resuelto, así que el aislamiento existente se aplica solo):

- `GET /reportes/consumo-colaborador?desde=&hasta=` (RRHH/ADMIN_EMPRESA) —
  por colaborador de la empresa: cantidad de pedidos, total bruto, subsidio
  recibido, monto a su cargo, en el rango.
- `GET /reportes/gasto-empresa?desde=&hasta=` (RRHH/ADMIN_EMPRESA; también
  plataforma, todas las empresas) — subsidio total aportado, cantidad de
  colaboradores que pidieron al menos una vez, cantidad de pedidos.
- `GET /reportes/entregas-suplidor?desde=&hasta=` (SUPLIDOR_ADMIN, lo
  propio; también plataforma) — pedidos por estado (`RECIBIDO`,
  `NO_ENTREGADO`, `DISPUTA`, cancelados), tasa de disputas sobre el total.
- `GET /reportes/disputas?desde=&hasta=` (RRHH/ADMIN_EMPRESA; también
  plataforma) — cantidad por motivo, y por resolución (a favor de quién).

### Subsprint 9.2 — Notificaciones por email

Tabla `notificacion_enviada` (auditoría, no cola de reintento): `id`,
`tipo`, `destinatario`, `asunto`, `estado` (`ENVIADA`|`ERROR`|`OMITIDA`),
`referencia_tipo`/`referencia_id` (ej. `PEDIDO`/`123`), `creado_en`,
`detalle_error`. `OMITIDA` es el caso sin `RESEND_API_KEY` configurada —
nunca bloquea el request que la disparó, solo queda registrado.

Tres disparadores reales, elegidos por ser los de mayor señal, no todos los
que existen (evita sobre-alcanzar):
1. Pedido pasa a `ENTREGADO` → email al colaborador (si tiene `email`) para
   que confirme.
2. Disputa resuelta (`resolver-disputa`) → email al colaborador con el
   resultado.
3. Lote de liquidación marcado `PAGADO` → no hay columna de email en
   `suplidor` todavía; se agrega `suplidor.email_contacto` (nullable) en
   esta migración para poder notificarlo.

`src/common/notificaciones.ts`: función `enviarNotificacion()` que llama al
API HTTP de Resend directo con `fetch`, registra el resultado en
`notificacion_enviada`, y **nunca lanza** — un fallo de envío no debe
tumbar la transacción que lo disparó (confirmar un pedido no debe fallar
porque el proveedor de email esté caído).

### Subsprint 9.3 — Observabilidad y endurecimiento básico

- `helmet` (headers de seguridad estándar) en `main.ts`.
- `@nestjs/throttler` en `/auth/login` — límite razonable (ej. 5 intentos
  por minuto por IP), responde 429 al excederlo.
- Interceptor simple de logging de requests: método, ruta, status, duración
  — usando el `Logger` que NestJS ya trae, sin servicio externo.
- Validación de variables de entorno críticas (`DATABASE_URL`,
  `MIGRATE_DATABASE_URL`, `PLATFORM_DATABASE_URL`, `JWT_SECRET`) al
  arrancar `main.ts` — falla rápido con un mensaje claro en vez de fallar
  a medias en el primer request que las necesite.

### Subsprint 9.4 — Despliegue real a Render

Requiere el prerrequisito de git/GitHub de arriba, confirmado antes de
tocarlo. Entregables:
- `render.yaml` — blueprint declarativo: build command (`npm ci && npm run
  build`), start command (`npm run start`), health check `/health`,
  variables de entorno declaradas (sin valores reales, esos se configuran
  en el dashboard de Render).
- Guía paso a paso en el README para: crear la cuenta, conectar el repo de
  GitHub, configurar las variables de entorno reales (`DATABASE_URL` de la
  rama de producción en Neon, `JWT_SECRET` propio, etc.), y correr
  `npm run migrate` contra la base de producción antes del primer deploy.

### Fuera de alcance de este sprint (a propósito)

- Notificaciones por SMS o push — solo email, por presupuesto.
- Reintentos automáticos de notificaciones fallidas — `notificacion_enviada`
  registra el fallo para revisión manual, no hay cola ni cron (mismo
  principio de "sin jobs en segundo plano" de todo el proyecto).
- Dashboards de observabilidad (Grafana, etc.) o servicios de pago (Sentry,
  New Relic) — logging básico a stdout, que Render ya captura por defecto.
- CI/CD con tests automáticos en cada push — Render puede desplegar en cada
  push, pero correr la suite de tests antes de cada deploy es una mejora
  futura, no de este sprint.

---

## Siguiente paso

Con el Sprint 1 y el Sprint 8 (sistema de ayuda) ya definidos, sigo con el Sprint 2 —back office de
empresas y contratos— con el mismo nivel de detalle, alineado con lo que ya validamos en
`portal-backoffice-onboarding.html`. Confírmame cuando quieras que empiece.
