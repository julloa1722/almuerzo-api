# CHANGELOG

Registro de cambios por sprint, mientras el proyecto no tiene control de
versiones real (git) — ver la nota en `plan-sprints.md`, Sprint 9. Cada
entrada resume qué cambió a nivel de archivo; el detalle de diseño,
decisiones y bugs reales está en `plan-sprints.md`.

Cada sprint confirmado tiene un snapshot restaurable en `versiones/` — ver
`versiones/README.md` para cómo volver a un estado anterior.

---

## Corrección post-cierre (31 de julio de 2026) — reportes de dinero ahora salen del libro mayor

Bug real, encontrado al revisar con el usuario si `plan-sprints.md`/`README.md`
decían de qué tabla salían los números de `GET /reportes/gasto-empresa`. No
lo decían, y la respuesta real era inconsistente con el Sprint 6: contaban
`pedido` directo (incluidos pedidos `ENTREGADO`/`DISPUTA` sin resolver), no
`movimiento` (el libro mayor, la fuente de verdad declarada en el Sprint 6).

**Archivos modificados:** `src/reportes/reportes.controller.ts`
(`consumo-colaborador` y `gasto-empresa` reescritos sobre `movimiento`),
`test/reportes.test.js` (+ prueba: un `ENTREGADO` sin `CARGO` no se cuenta),
`plan-sprints.md`, `README.md`. También se corrigieron 5 líneas obsoletas
"Falta: confirmación..." en `plan-sprints.md` que quedaron sin actualizar
al marcar los Sprints 5–9 como confirmados.

## Cierre de roadmap (30 de julio de 2026) — Sprint 4 confirmado + hueco de descubrimiento de menú resuelto

Sin sprint propio: al preguntar "qué falta para concluir el proyecto" se
cerraron los dos pendientes que quedaban abiertos.

**Archivos modificados:** `src/pedidos/pedidos.controller.ts` (+`GET
/pedidos/menu-disponible`), `plan-sprints.md` (Sprint 4 → ✅ CONFIRMADO; nota
de alcance del Sprint 5 marcada como resuelta), `README.md`.

## Sprint 9 — Operación y lanzamiento (subsprints 9.1–9.3 ✅ CONFIRMADOS; 9.4 preparado sin ejecutar — bloqueado por falta de git)

**Migraciones:** `migrations/0014_notificaciones.sql` (`suplidor.email_contacto`, tabla `notificacion_enviada`).

**Archivos nuevos:**
- `src/reportes/` (`reportes.controller.ts`, `reportes.module.ts`)
- `src/notificaciones/` (`notificaciones.controller.ts`, `notificaciones.module.ts`)
- `src/common/notificaciones.ts`, `src/common/request-logging.interceptor.ts`, `src/common/validar-entorno.ts`
- `render.yaml`, `.gitignore`
- `test/reportes.test.js`, `test/notificaciones.test.js`

**Archivos modificados:** `src/app.module.ts`, `src/main.ts`, `src/auth/auth.module.ts`, `src/auth/auth.controller.ts`, `src/pedidos/pedidos.controller.ts` (disparadores de notificación en `entregarPedido`/`resolverDisputa`), `src/liquidaciones/liquidaciones.controller.ts` (disparador en `marcarPagado`), `.env.example`, `README.md`, `CLAUDE.md`, `package.json` (+`helmet`, `+@nestjs/throttler`).

## Sprint 8 — Sistema de ayuda (solo backend) ✅ CONFIRMADO

**Migraciones:** `migrations/0012_ayuda_contenido.sql`, `migrations/0013_ayuda_contenido_solo_lectura_app.sql`.

**Archivos nuevos:** `src/ayuda/` (`ayuda.controller.ts`, `ayuda.module.ts`, `dto.ts`), `test/ayuda.test.js`.

**Archivos modificados:** `src/app.module.ts`, `scripts/seed.js` (5 fichas de ayuda reales), `README.md`, `CLAUDE.md`.

## Sprint 7 — Liquidación a suplidores ✅ CONFIRMADO

**Migraciones:** `migrations/0011_liquidacion_suplidores.sql`.

**Archivos nuevos:** `src/liquidaciones/` (`liquidaciones.controller.ts`, `liquidaciones.module.ts`, `dto.ts`), `test/liquidaciones.test.js`.

**Archivos modificados:** `src/pedidos/pedidos.controller.ts` (aplica `ajuste_pct` en `crearPedido` — bug real corregido, existía desde el Sprint 2 sin usarse), `src/pedidos/elegibilidad.util.ts` (+`aplicarAjustePct`), `src/app.module.ts`, `README.md`, `CLAUDE.md`.

## Sprint 6 — Nómina y libro mayor ✅ CONFIRMADO

**Migraciones:** `migrations/0010_libro_mayor_y_ciclos.sql`.

**Archivos nuevos:** `src/nomina/` (`nomina.controller.ts`, `nomina.module.ts`, `dto.ts`, `campos-reporte.ts`), `src/common/libro-mayor.ts`, `test/nomina.test.js`.

**Archivos modificados:** `src/pedidos/pedidos.controller.ts` (postea `CARGO` al libro mayor en los 3 puntos donde un pedido llega a `RECIBIDO`), `src/app.module.ts`, `README.md`, `CLAUDE.md`.

## Sprint 5 — Entrega, disputas y política de silencio ✅ CONFIRMADO

**Migraciones:** `migrations/0008_entrega_disputas_silencio.sql`, `migrations/0009_contrato_suplidor_visible_para_suplidor.sql` (bug real: RLS de `contrato_suplidor` bloqueaba la propia subconsulta de la política del suplidor).

**Archivos nuevos:** `test/entrega-disputas.test.js`.

**Archivos modificados:** `src/pedidos/pedidos.controller.ts` (endpoints de suplidor y colaborador para el ciclo de entrega/disputa, resolución perezosa por silencio), `src/pedidos/dto.ts`, `src/common/calendario.util.ts` (+`ventanaSilencioVencida`/`ventanaSilencioVenceEn`), `README.md`, `CLAUDE.md`. Borrado: `src/catalogo/calendario.util.ts` (código muerto, duplicado sin uso).

## Sprint 4 — Motor de pedidos (construido y probado, pendiente de confirmación del usuario)

**Migraciones:** `migrations/0006_programa_y_pedidos.sql`, `migrations/0007_lectura_cruzada_contrato.sql` (bug real: RLS por suplidor bloqueaba la lectura del menú para colaboradores).

**Archivos nuevos:** `src/pedidos/` completo, `test/pedidos.test.js`.

**Archivos modificados:** `src/app.module.ts`, `README.md`.

## Sprint 3 — Catálogo y menú del suplidor ✅ CONFIRMADO

**Migraciones:** `migrations/0005_catalogo_y_menu.sql`.

**Archivos nuevos:** `src/catalogo/` completo, `src/common/calendario.util.ts`, `test/catalogo.test.js`.

## Sprint 2 — Back office: empresas, colaboradores y contratos ✅ CONFIRMADO

**Migraciones:** `migrations/0004_contratos_y_rol_plataforma.sql`.

**Archivos nuevos:** `src/back-office/` completo, `test/back-office.test.js`.

## Sprint 1 — Fundación técnica e identidad ✅ CONFIRMADO

**Migraciones:** `migrations/0001_extensiones.sql`, `0002_identidad.sql`, `0003_rls.sql`.

Base del proyecto: NestJS, `scripts/migrate.js`, `src/auth/`, `src/identidad/`, `src/common/` (guards, interceptor de tenant, tipos de pg), `src/db/`, `test/tenant-isolation.test.js`, `scripts/smoke-test.js`, `scripts/seed.js`.
