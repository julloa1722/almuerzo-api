# CLAUDE.md — Contexto del proyecto

Backend de una plataforma de almuerzo corporativo (SaaS multi-empresa), estilo
Fripick, para el mercado dominicano. Proyecto personal — sin presupuesto de
empresa, sin restricciones regulatorias de salud.

**Antes de tocar código, lee `plan-sprints.md`** en la raíz del proyecto — es
la fuente de verdad del roadmap, con cada sprint documentado (objetivo,
subsprints, criterio de cierre) y marcado como ✅ CONFIRMADO solo cuando el
usuario lo probó en su propia máquina y lo confirmó explícitamente.

## Regla de trabajo, no negociable

1. Antes de construir un sprint nuevo, escribe primero su desglose en
   `plan-sprints.md` (objetivo, subsprints, criterio de cierre). No construyas
   antes de documentar — es un error que ya se cometió dos veces en este
   proyecto y se corrigió a partir del Sprint 4.
2. Construye, corre las migraciones y los tests **contra una base de datos
   real** (Neon, no mocks). Nunca declares un sprint terminado sin haberlo
   corrido de verdad.
3. Cada sprint termina en un entregable concreto que el usuario prueba en su
   propia máquina. No se avanza al siguiente sprint sin su confirmación
   explícita.
4. Si cambias `package.json` (nueva dependencia, versión), asegúrate de que
   el usuario tenga el archivo completo actualizado — no le pidas que edite
   una línea a mano; ya causó desincronización una vez en este proyecto.
5. Cuando encuentres un bug real durante el desarrollo (no un malentendido de
   prueba), corrígelo y documéntalo en `plan-sprints.md` bajo el sprint
   correspondiente — este proyecto tiene el hábito de dejar constancia de
   los bugs reales encontrados, no solo del código final.

## Decisiones de arquitectura ya tomadas (no las reabras sin razón nueva)

- **PostgreSQL en Neon**, sin Docker — desarrollo directo contra una rama de Neon.
- **SQL directo con un migrador propio** (`scripts/migrate.js`), no un ORM.
  Las migraciones viven en `migrations/*.sql`, aplicadas en orden alfabético.
- **RLS (Row Level Security) como mecanismo de aislamiento**, no filtros de
  aplicación. Patrón establecido:
  - `almuerzo_app`: rol sin `BYPASSRLS`, usado por la app y los tests. Aísla
    por `app.empresa_id` o `app.suplidor_id` (GUC fijado por
    `TenantContextInterceptor` según el ámbito del JWT).
  - `almuerzo_platform`: rol con `BYPASSRLS` a propósito, solo para back
    office (`SUPERADMIN`/`SOPORTE`, ámbito `PLATAFORMA`).
  - Tablas sin columna de tenant directa (ej. `plantilla_item`,
    `pedido_linea`) denormalizan `suplidor_id`/`empresa_id` para que la
    política de RLS sea una comparación simple, no un `EXISTS` con subconsulta.
  - Cuando dos ámbitos legítimamente necesitan ver los mismos datos con
    reglas distintas (ej. el suplidor gestiona su menú, la empresa contratada
    lo lee para pedir), se usan **múltiples políticas permisivas** en la misma
    tabla — Postgres las combina con `OR`. Ver `migrations/0007` como ejemplo.
- **bcryptjs**, no argon2 (evita compilación nativa).
- **BIGINT se parsea a `number` en JS**, no a string (`src/common/pg-tipos.ts`)
  — decisión consciente, documentada, por el volumen de este sistema.
- **NUMERIC se deja como string** (comportamiento default de `pg`) — a
  propósito, para no perder precisión en montos de dinero.
- **Ningún job en segundo plano todavía.** Estados como el congelamiento de
  `menu_dia` se calculan al vuelo contra el reloj real en cada request, no se
  guardan en una columna mutable.
- **Hosting futuro (no construido aún):** Render (plan gratuito) para la API,
  Neon para la base. Ver `plan-sprints.md`, Sprint 9.

## Comandos que ya existen

```bash
npm run migrate      # aplica migrations/*.sql pendientes
npm run seed         # datos de prueba (empresas, colaboradores, suplidores, usuarios)
npm run build        # compila TypeScript a dist/
npm run start        # corre la API compilada
npm run start:dev    # con recarga automática
npm run smoke        # scripts/smoke-test.js — flujo end-to-end con fetch nativo
npm run test          # test/tenant-isolation.test.js — RLS del Sprint 1
node test/back-office.test.js   # Sprint 2
node test/catalogo.test.js      # Sprint 3
node test/pedidos.test.js       # Sprint 4
node test/entrega-disputas.test.js  # Sprint 5
node test/nomina.test.js            # Sprint 6
node test/liquidaciones.test.js     # Sprint 7
node test/ayuda.test.js             # Sprint 8
node test/reportes.test.js          # Sprint 9
node test/notificaciones.test.js    # Sprint 9
```

## Usuarios de prueba (creados por `npm run seed`)

| Email | Password | Rol / Ámbito |
|---|---|---|
| `rrhh@futuroars.demo` | `rrhh123456` | RRHH, empresa Futuro ARS |
| `admin@plataforma.demo` | `admin123456` | SUPERADMIN, plataforma |
| `suplidor@cocinacriolla.demo` | `suplidor123456` | SUPLIDOR_ADMIN, Cocina Criolla del Este |
| `ana.ramirez@futuroars.demo` | `colaborador123456` | COLABORADOR, Futuro ARS |

## Estado actual

Revisa `plan-sprints.md` para el estado exacto de cada sprint. Al momento de
escribir este archivo, Sprints 1–9 confirmados por el usuario (Sprint 8 con
alcance recortado a solo el backend de contenido de ayuda — el tour visual
y el centro de ayuda quedaron diferidos hasta que exista un frontend). El
único pendiente del roadmap actual es el subsprint 9.4 (despliegue real a
Render) — preparado (`render.yaml` + guía) pero **no ejecutado**: git no
está instalado en esta máquina y esta sesión no pudo instalarlo (el entorno
de ejecución bloquea descargas de binarios; ver plan-sprints.md, Sprint 9).
Mientras tanto, el proyecto lleva su historial en `CHANGELOG.md` y
snapshots restaurables en `versiones/` en vez de git — mantén ambos al día
en cada cambio significativo, hasta que exista git de verdad.

También se agregó `GET /pedidos/menu-disponible`, fuera de cualquier sprint
formal — cerraba un hueco real (el colaborador no tenía forma de descubrir
qué pedir sin conocer `suplidorId`/`menuDiaId` de antemano), anotado desde
el Sprint 5 y resuelto el 30 de julio de 2026 al preguntar qué faltaba para
concluir el proyecto.
