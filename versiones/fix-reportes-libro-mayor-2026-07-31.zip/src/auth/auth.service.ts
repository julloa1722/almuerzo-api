import {
  BadRequestException,
  ConflictException,
  Inject,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcryptjs';
import { Pool } from 'pg';
import { PG_POOL } from '../db/db.module';
import { Ambito } from '../common/tipos';
import { LoginDto, RegistroDto } from './dto';

interface MembresiaRow {
  id: number;
  ambito_tipo: string;
  ambito_id: number | null;
  rol: string;
  nombre_ambito: string | null;
}

@Injectable()
export class AuthService {
  constructor(
    @Inject(PG_POOL) private readonly pool: Pool,
    private readonly jwt: JwtService,
  ) {}

  async registrar(dto: RegistroDto) {
    if (!dto.email || !dto.password) {
      throw new BadRequestException('email y password son obligatorios.');
    }
    if (dto.password.length < 8) {
      throw new BadRequestException('La contraseña debe tener al menos 8 caracteres.');
    }

    const existente = await this.pool.query('SELECT id FROM usuario WHERE email = $1', [dto.email]);
    if (existente.rowCount) {
      throw new ConflictException('Ya existe una cuenta con ese correo.');
    }

    const hash = await bcrypt.hash(dto.password, 10);
    const { rows } = await this.pool.query(
      `INSERT INTO usuario (email, password_hash) VALUES ($1, $2) RETURNING id, email`,
      [dto.email, hash],
    );
    return { usuarioId: rows[0].id, email: rows[0].email };
  }

  /**
   * Login sin ámbito: solo confirma identidad y devuelve las membresías
   * disponibles para que el cliente elija con cuál entrar (subsprint 1.3).
   */
  async login(dto: LoginDto) {
    const { rows } = await this.pool.query(
      'SELECT id, password_hash, estado FROM usuario WHERE email = $1',
      [dto.email],
    );
    const usuario = rows[0];
    if (!usuario || usuario.estado !== 'ACTIVO') {
      throw new UnauthorizedException('Credenciales inválidas.');
    }
    const coincide = await bcrypt.compare(dto.password, usuario.password_hash);
    if (!coincide) {
      throw new UnauthorizedException('Credenciales inválidas.');
    }

    const membresias = await this.membresiasDe(usuario.id);
    const tokenSinAmbito = this.jwt.sign({ sub: usuario.id });

    return {
      accessToken: tokenSinAmbito,
      membresias: membresias.map((m) => ({
        membresiaId: m.id,
        ambitoTipo: m.ambito_tipo,
        ambitoId: m.ambito_id,
        rol: m.rol,
        nombre: m.nombre_ambito,
      })),
    };
  }

  /**
   * Con el token sin ámbito, el usuario elige una de sus membresías y recibe
   * un token nuevo que sí trae el ambito — ese es el que consume
   * TenantContextInterceptor para fijar el GUC de RLS.
   */
  async seleccionarAmbito(usuarioId: number, membresiaId: number) {
    const membresias = await this.membresiasDe(usuarioId);
    const elegida = membresias.find((m) => m.id === membresiaId);
    if (!elegida) {
      throw new UnauthorizedException('Esa membresía no pertenece a este usuario o no existe.');
    }

    const ambito: Ambito = {
      tipo: elegida.ambito_tipo as Ambito['tipo'],
      id: elegida.ambito_id,
      rol: elegida.rol,
    };
    const accessToken = this.jwt.sign({ sub: usuarioId, ambito });

    return { accessToken, ambito };
  }

  private async membresiasDe(usuarioId: number): Promise<MembresiaRow[]> {
    const { rows } = await this.pool.query<MembresiaRow>(
      `SELECT
         m.id, m.ambito_tipo, m.ambito_id, m.rol,
         COALESCE(e.nombre, s.nombre, 'Plataforma') AS nombre_ambito
       FROM membresia m
       LEFT JOIN empresa e ON m.ambito_tipo = 'EMPRESA' AND e.id = m.ambito_id
       LEFT JOIN suplidor s ON m.ambito_tipo = 'SUPLIDOR' AND s.id = m.ambito_id
       WHERE m.usuario_id = $1 AND m.estado = 'ACTIVA'
       ORDER BY m.id`,
      [usuarioId],
    );
    return rows;
  }
}
