import {
  BadRequestException,
  Body,
  Controller,
  Get,
  NotFoundException,
  Param,
  ParseIntPipe,
  Patch,
  Post,
  Req,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { Request } from 'express';
import { JwtAuthGuard } from '../common/jwt-auth.guard';
import { Roles, RolesGuard } from '../common/roles.guard';
import { TenantContextInterceptor } from '../common/tenant-context.interceptor';
import { validarCsvColaboradores } from './csv-colaboradores';
import {
  CrearContratoDto,
  CrearEmpresaDto,
  EditarContratoDto,
  ImportarColaboradoresDto,
} from './dto';

/** Ámbito PLATAFORMA, roles SUPERADMIN/SOPORTE — es el equivalente en código
 * del portal-backoffice-onboarding.html: alta de empresas y contratos, algo
 * que ninguna empresa individual gestiona sobre sí misma. */
@Controller('back-office')
@UseGuards(JwtAuthGuard, RolesGuard)
@UseInterceptors(TenantContextInterceptor)
@Roles('SUPERADMIN', 'SOPORTE')
export class BackOfficeController {
  // ---------- Empresas ----------

  @Get('empresas')
  async listarEmpresas(@Req() req: Request) {
    const { rows } = await req.dbClient!.query(
      `SELECT e.id, e.rnc, e.nombre, e.frecuencia_nomina, e.estado,
              (SELECT COUNT(*) FROM colaborador c WHERE c.empresa_id = e.id AND c.estado = 'ACTIVO') AS colaboradores,
              (SELECT COUNT(*) FROM contrato_suplidor cs WHERE cs.empresa_id = e.id AND cs.estado = 'ACTIVA') AS suplidores_activos
       FROM empresa e
       ORDER BY e.nombre`,
    );
    return { empresas: rows };
  }

  @Post('empresas')
  async crearEmpresa(@Req() req: Request, @Body() dto: CrearEmpresaDto) {
    if (!dto.nombre?.trim()) throw new BadRequestException('nombre es obligatorio.');
    if (!/^\d{3}-?\d{5,8}-?\d?$/.test(dto.rnc ?? '')) {
      throw new BadRequestException('rnc no tiene un formato reconocido.');
    }
    const { rows } = await req.dbClient!.query(
      `INSERT INTO empresa (rnc, nombre, frecuencia_nomina)
       VALUES ($1, $2, $3)
       RETURNING id, rnc, nombre, frecuencia_nomina, estado`,
      [dto.rnc, dto.nombre.trim(), dto.frecuenciaNomina ?? 'QUINCENAL'],
    );
    return rows[0];
  }

  // ---------- Importación de colaboradores ----------
  // Soporta dos formas de envío del mismo CSV:
  //   (a) multipart/form-data con el archivo en el campo "file"
  //   (b) application/json con el contenido del CSV como texto en { csv: "..." }
  // "preview" nunca escribe en la base; "importar" sí, y solo las filas sin errores.

  @Post('empresas/:empresaId/colaboradores/preview')
  @UseInterceptors(FileInterceptor('file'))
  async previsualizarColaboradores(
    @Req() req: Request,
    @Param('empresaId', ParseIntPipe) empresaId: number,
    @UploadedFile() file: Express.Multer.File | undefined,
    @Body() dto: ImportarColaboradoresDto,
  ) {
    const csv = await this.obtenerContenidoCsv(file, dto);
    const puntos = await this.puntosValidosDe(req, empresaId);
    const filas = validarCsvColaboradores(csv, puntos);
    return this.resumenDeFilas(filas);
  }

  @Post('empresas/:empresaId/colaboradores/importar')
  @UseInterceptors(FileInterceptor('file'))
  async importarColaboradores(
    @Req() req: Request,
    @Param('empresaId', ParseIntPipe) empresaId: number,
    @UploadedFile() file: Express.Multer.File | undefined,
    @Body() dto: ImportarColaboradoresDto,
  ) {
    const csv = await this.obtenerContenidoCsv(file, dto);
    const puntosMapa = await this.mapaPuntosDe(req, empresaId);
    const filas = validarCsvColaboradores(csv, new Set(puntosMapa.keys()));

    const importables = filas.filter((f) => f.errores.length === 0);
    let importados = 0;
    for (const fila of importables) {
      const d = fila.datos;
      const puntoId = d.punto_entrega ? puntosMapa.get(d.punto_entrega) ?? null : null;
      await req.dbClient!.query(
        `INSERT INTO colaborador
           (empresa_id, codigo_nomina, cedula, nombre_completo, email, punto_entrega_id, salario_neto_ref, fecha_ingreso)
         VALUES ($1, $2, $3, $4, $5, $6, $7, CURRENT_DATE)
         ON CONFLICT (empresa_id, codigo_nomina) DO UPDATE SET
           nombre_completo = EXCLUDED.nombre_completo,
           email = EXCLUDED.email,
           punto_entrega_id = EXCLUDED.punto_entrega_id,
           salario_neto_ref = EXCLUDED.salario_neto_ref`,
        [
          empresaId,
          d.codigo_nomina,
          d.cedula,
          d.nombre_completo,
          d.email || null,
          puntoId,
          d.salario_neto || null,
        ],
      );
      importados++;
    }

    return { ...this.resumenDeFilas(filas), importados };
  }

  private async obtenerContenidoCsv(
    file: Express.Multer.File | undefined,
    dto: ImportarColaboradoresDto,
  ): Promise<string> {
    if (file) return file.buffer.toString('utf-8');
    if (dto?.csv) return dto.csv;
    throw new BadRequestException(
      'Envía el CSV como archivo (campo "file", multipart/form-data) o como texto en el body ({ "csv": "..." }).',
    );
  }

  private async puntosValidosDe(req: Request, empresaId: number): Promise<Set<string>> {
    const { rows } = await req.dbClient!.query(
      `SELECT nombre FROM punto_entrega WHERE empresa_id = $1 AND estado = 'ACTIVO'`,
      [empresaId],
    );
    return new Set(rows.map((r: { nombre: string }) => r.nombre));
  }

  private async mapaPuntosDe(req: Request, empresaId: number): Promise<Map<string, number>> {
    const { rows } = await req.dbClient!.query(
      `SELECT id, nombre FROM punto_entrega WHERE empresa_id = $1 AND estado = 'ACTIVO'`,
      [empresaId],
    );
    return new Map(rows.map((r: { id: number; nombre: string }) => [r.nombre, r.id]));
  }

  private resumenDeFilas(filas: ReturnType<typeof validarCsvColaboradores>) {
    const conError = filas.filter((f) => f.errores.length > 0);
    const conAlerta = filas.filter((f) => f.errores.length === 0 && f.alertas.length > 0);
    const limpias = filas.filter((f) => f.errores.length === 0 && f.alertas.length === 0);
    return {
      totalFilas: filas.length,
      limpias: limpias.length,
      conAlerta: conAlerta.length,
      conError: conError.length,
      importables: filas.filter((f) => f.errores.length === 0).length,
      filas,
    };
  }

  // ---------- Contratos con suplidores ----------

  @Get('empresas/:empresaId/contratos')
  async listarContratos(@Req() req: Request, @Param('empresaId', ParseIntPipe) empresaId: number) {
    const { rows } = await req.dbClient!.query(
      `SELECT cs.id, cs.suplidor_id, s.nombre AS suplidor_nombre, s.rnc AS suplidor_rnc,
              cs.ajuste_pct, cs.estado
       FROM contrato_suplidor cs
       JOIN suplidor s ON s.id = cs.suplidor_id
       WHERE cs.empresa_id = $1
       ORDER BY s.nombre`,
      [empresaId],
    );
    return { contratos: rows };
  }

  @Post('empresas/:empresaId/contratos')
  async crearContrato(
    @Req() req: Request,
    @Param('empresaId', ParseIntPipe) empresaId: number,
    @Body() dto: CrearContratoDto,
  ) {
    const empresa = await req.dbClient!.query('SELECT id FROM empresa WHERE id = $1', [empresaId]);
    if (!empresa.rowCount) throw new NotFoundException('Empresa no encontrada.');

    const { rows } = await req.dbClient!.query(
      `INSERT INTO contrato_suplidor (empresa_id, suplidor_id, ajuste_pct)
       VALUES ($1, $2, $3)
       ON CONFLICT (empresa_id, suplidor_id) DO UPDATE SET estado = 'ACTIVA'
       RETURNING id, suplidor_id, ajuste_pct, estado`,
      [empresaId, dto.suplidorId, dto.ajustePct ?? 0],
    );
    return rows[0];
  }

  @Patch('contratos/:contratoId')
  async editarContrato(
    @Req() req: Request,
    @Param('contratoId', ParseIntPipe) contratoId: number,
    @Body() dto: EditarContratoDto,
  ) {
    const { rows } = await req.dbClient!.query(
      `UPDATE contrato_suplidor
       SET ajuste_pct = COALESCE($2, ajuste_pct),
           estado = COALESCE($3, estado)
       WHERE id = $1
       RETURNING id, suplidor_id, ajuste_pct, estado`,
      [contratoId, dto.ajustePct ?? null, dto.estado ?? null],
    );
    if (!rows.length) throw new NotFoundException('Contrato no encontrado.');
    return rows[0];
  }
}
