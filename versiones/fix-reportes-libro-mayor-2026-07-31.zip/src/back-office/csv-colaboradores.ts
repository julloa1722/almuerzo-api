import { parse } from 'csv-parse/sync';

export interface FilaColaborador {
  numeroFila: number; // 1-indexed, contando el encabezado como fila 1
  datos: {
    codigo_nomina?: string;
    cedula?: string;
    nombre_completo?: string;
    email?: string;
    punto_entrega?: string;
    salario_neto?: string;
  };
  errores: string[];
  alertas: string[];
}

const CEDULA_RE = /^\d{3}-?\d{7}-?\d$/;

/**
 * Reglas idénticas a las que se validaron en el mockup portal-backoffice-onboarding.html:
 * código y cédula obligatorios y únicos dentro del archivo, nombre obligatorio,
 * cédula con formato válido, salario numérico positivo si viene, y punto de
 * entrega que no matchea ninguno existente se marca ALERTA (se importa igual,
 * sin bloquear), no ERROR.
 */
export function validarCsvColaboradores(
  contenidoCsv: string,
  puntosValidos: Set<string>,
): FilaColaborador[] {
  const registros: Record<string, string>[] = parse(contenidoCsv, {
    columns: true,
    skip_empty_lines: true,
    trim: true,
    bom: true,
  });

  const filas: FilaColaborador[] = registros.map((datos, i) => ({
    numeroFila: i + 2, // +1 por 1-index, +1 por el encabezado
    datos,
    errores: [],
    alertas: [],
  }));

  const vistoCodigo = new Map<string, number>();
  const vistoCedula = new Map<string, number>();

  for (const fila of filas) {
    const d = fila.datos;

    if (!d.codigo_nomina) fila.errores.push('Falta código de nómina.');
    if (!d.nombre_completo) fila.errores.push('Falta el nombre completo.');
    if (!d.cedula || !CEDULA_RE.test(d.cedula)) {
      fila.errores.push(`Cédula con formato inválido: "${d.cedula ?? ''}".`);
    }
    if (!d.punto_entrega) {
      fila.errores.push('Falta punto de entrega.');
    } else if (!puntosValidos.has(d.punto_entrega)) {
      fila.alertas.push(`Punto de entrega "${d.punto_entrega}" no coincide con ningún punto configurado.`);
    }
    if (d.salario_neto && (isNaN(Number(d.salario_neto)) || Number(d.salario_neto) <= 0)) {
      fila.errores.push('Salario neto inválido.');
    }

    if (d.codigo_nomina) {
      const previa = vistoCodigo.get(d.codigo_nomina);
      if (previa) fila.errores.push(`Código de nómina duplicado en el archivo (fila ${previa}).`);
      else vistoCodigo.set(d.codigo_nomina, fila.numeroFila);
    }
    if (d.cedula && CEDULA_RE.test(d.cedula)) {
      const previa = vistoCedula.get(d.cedula);
      if (previa) fila.errores.push(`Cédula duplicada en el archivo (fila ${previa}).`);
      else vistoCedula.set(d.cedula, fila.numeroFila);
    }
  }

  return filas;
}
