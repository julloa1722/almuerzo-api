import { Controller, Get, Req, UseGuards, UseInterceptors } from '@nestjs/common';
import { Request } from 'express';
import { JwtAuthGuard } from '../common/jwt-auth.guard';
import { Roles, RolesGuard } from '../common/roles.guard';
import { TenantContextInterceptor } from '../common/tenant-context.interceptor';

/**
 * Endpoint deliberadamente simple: lista los colaboradores del ámbito activo.
 * Su único propósito en el Sprint 1 es servir de prueba viviente del aislamiento
 * por RLS — no lleva paginación, filtros ni nada de negocio real todavía.
 */
@Controller('colaboradores')
@UseGuards(JwtAuthGuard, RolesGuard)
@UseInterceptors(TenantContextInterceptor)
export class IdentidadController {
  @Get()
  @Roles('RRHH', 'ADMIN_EMPRESA')
  async listar(@Req() req: Request) {
    const { rows } = await req.dbClient!.query(
      `SELECT id, codigo_nomina, nombre_completo, estado
       FROM colaborador
       ORDER BY nombre_completo`,
    );
    return { ambito: req.ambito, colaboradores: rows };
  }
}
