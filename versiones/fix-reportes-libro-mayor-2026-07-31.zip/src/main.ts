import 'reflect-metadata';
import 'dotenv/config';
import './common/pg-tipos';
import helmet from 'helmet';
import { NestFactory } from '@nestjs/core';
import { ConfigService } from '@nestjs/config';
import { AppModule } from './app.module';
import { RequestLoggingInterceptor } from './common/request-logging.interceptor';
import { validarVariablesDeEntorno } from './common/validar-entorno';

async function bootstrap() {
  // Antes de construir el módulo de Nest — falla rápido con un mensaje
  // claro, no a medias en el primer request que necesite la variable.
  validarVariablesDeEntorno();

  const app = await NestFactory.create(AppModule);
  app.use(helmet());
  app.useGlobalInterceptors(new RequestLoggingInterceptor());

  const config = app.get(ConfigService);
  const port = config.get<number>('PORT', 3000);
  await app.listen(port);
  // eslint-disable-next-line no-console
  console.log(`almuerzo-api escuchando en http://localhost:${port}`);
}

bootstrap();
