import { CampoPlantilla } from './campos-reporte';

export interface CerrarCicloDto {
  periodoInicio?: string; // YYYY-MM-DD; si falta, usa el período vigente hoy
  periodoFin?: string;
}

export type TipoMovimientoManual = 'CARGO' | 'NOTA_CREDITO';

export interface AjusteMovimientoDto {
  colaboradorId: number;
  tipo: TipoMovimientoManual;
  monto: number;
  motivo: string;
}

export interface ActualizarPlantillaDto {
  campos: CampoPlantilla[];
}
