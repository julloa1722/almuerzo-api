import { Module } from '@nestjs/common';
import { AuthModule } from '../auth/auth.module';
import { NominaController } from './nomina.controller';

@Module({
  imports: [AuthModule],
  controllers: [NominaController],
})
export class NominaModule {}
