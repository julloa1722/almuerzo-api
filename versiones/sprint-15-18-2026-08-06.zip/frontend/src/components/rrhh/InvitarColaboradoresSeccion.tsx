import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useApi } from '../../lib/useApi';
import { ApiError } from '../../lib/api';
import { Aviso } from '../Aviso';
import type { Colaborador, Invitacion } from '../../types';

/**
 * Sprint 18, subsprint 18.6: colaboradores cargados por CSV (Sprint 2/13/16)
 * no tienen ninguna forma de loguearse hasta que alguien los invite — este
 * es exactamente ese "alguien". Solo se ofrece invitar a los que todavía no
 * tienen `usuario_id`.
 */
export function InvitarColaboradoresSeccion() {
  const api = useApi();
  const queryClient = useQueryClient();
  const [emailPorColaborador, setEmailPorColaborador] = useState<Record<number, string>>({});
  const [error, setError] = useState<string | null>(null);
  const [ultimoLink, setUltimoLink] = useState<string | null>(null);

  const { data: dataColabs, isLoading } = useQuery({
    queryKey: ['rrhh-colaboradores'],
    queryFn: () => api<{ colaboradores: Colaborador[] }>('/colaboradores'),
  });
  const { data: dataInv } = useQuery({
    queryKey: ['rrhh-invitaciones'],
    queryFn: () => api<{ invitaciones: Invitacion[] }>('/invitaciones'),
  });

  const invitar = useMutation({
    mutationFn: ({ colaboradorId, email }: { colaboradorId: number; email: string }) =>
      api<{ link: string }>('/invitaciones', { method: 'POST', body: { email, rol: 'COLABORADOR', colaboradorId } }),
    onSuccess: (resp) => {
      setError(null);
      setUltimoLink(resp.link);
      queryClient.invalidateQueries({ queryKey: ['rrhh-invitaciones'] });
    },
    onError: (err) => setError(err instanceof ApiError ? err.message : 'No se pudo enviar la invitación.'),
  });

  const sinCuenta = (dataColabs?.colaboradores ?? []).filter((c) => !c.usuario_id);
  const invitacionesPendientes = new Set(
    (dataInv?.invitaciones ?? []).filter((i) => i.estado === 'PENDIENTE').map((i) => i.email),
  );

  return (
    <div className="card mt-4">
      <h3>Invitar colaboradores</h3>
      <p className="text-[13px] text-muted mb-3">
        Un colaborador cargado por CSV no puede pedir almuerzo hasta que active su cuenta. Ponle su correo y
        envíale la invitación.
      </p>

      {error && <Aviso tipo="no">{error}</Aviso>}
      {ultimoLink && (
        <Aviso tipo="si">
          Invitación enviada. Si no hay servicio de correo configurado, copia el enlace: <br />
          <span className="mono text-[11.5px] break-all">{ultimoLink}</span>
        </Aviso>
      )}

      {isLoading && <div className="text-sm text-muted">Cargando…</div>}
      {!isLoading && sinCuenta.length === 0 && (
        <div className="vacio">Todos tus colaboradores ya tienen cuenta activa.</div>
      )}

      {sinCuenta.map((c) => {
        const email = emailPorColaborador[c.id] ?? '';
        const yaInvitado = email && invitacionesPendientes.has(email);
        return (
          <div key={c.id} className="flex items-center gap-1.5 mb-2">
            <span className="flex-1 min-w-0 truncate text-[13px]">
              {c.nombre_completo} <span className="mono text-[11.5px] text-muted">({c.codigo_nomina})</span>
            </span>
            <input
              className="w-56 text-xs"
              placeholder="correo del colaborador"
              value={email}
              onChange={(e) => setEmailPorColaborador({ ...emailPorColaborador, [c.id]: e.target.value })}
            />
            <button
              className="btn btn-sm flex-none"
              disabled={!email.trim() || invitar.isPending || !!yaInvitado}
              onClick={() => invitar.mutate({ colaboradorId: c.id, email: email.trim() })}
            >
              {yaInvitado ? 'Invitación enviada' : 'Invitar'}
            </button>
          </div>
        );
      })}
    </div>
  );
}
