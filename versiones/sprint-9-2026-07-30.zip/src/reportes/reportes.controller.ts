import { Controller, Get, Query, Req, UseGuards, UseInterceptors } from '@nestjs/common';
import { Request } from 'express';
import { JwtAuthGuard } from '../common/jwt-auth.guard';
import { Roles, RolesGuard } from '../common/roles.guard';
import { TenantContextInterceptor } from '../common/tenant-context.interceptor';
import { iso } from '../common/calendario.util';

/**
 * Reportes de solo lectura, agregando sobre tablas que ya existen — sin
 * tablas nuevas. Cada query corre en la transacción con el ámbito ya
 * resuelto (TenantContextInterceptor), así que el aislamiento RLS existente
 * se aplica solo: RRHH/ADMIN_EMPRESA nunca ve otra empresa, SUPLIDOR_ADMIN
 * nunca ve otro suplidor. Solo plataforma (bypass) ve todo, y únicamente en
 * los reportes agregados (gasto-empresa, entregas-suplidor, disputas) —
 * consumo-colaborador es a propósito exclusivo de la propia empresa: es
 * información a nivel de persona, no le corresponde a un ámbito cruzado.
 */
@Controller('reportes')
@UseGuards(JwtAuthGuard, RolesGuard)
@UseInterceptors(TenantContextInterceptor)
export class ReportesController {
  @Get('consumo-colaborador')
  @Roles('RRHH', 'ADMIN_EMPRESA')
  async consumoColaborador(@Req() req: Request, @Query('desde') desdeQ?: string, @Query('hasta') hastaQ?: string) {
    const { desde, hasta } = this.rango(desdeQ, hastaQ);
    const { rows } = await req.dbClient!.query(
      `SELECT c.id, c.codigo_nomina, c.nombre_completo,
              COUNT(p.id) AS cantidad_pedidos,
              COALESCE(SUM(p.total_bruto), 0) AS total_bruto,
              COALESCE(SUM(p.subsidio_empresa), 0) AS subsidio_total,
              COALESCE(SUM(p.monto_colaborador), 0) AS monto_colaborador_total
       FROM colaborador c
       LEFT JOIN pedido p ON p.colaborador_id = c.id
         AND p.fecha_servicio BETWEEN $1 AND $2
         AND p.estado NOT IN ('CANCELADO', 'NO_ENTREGADO')
       GROUP BY c.id, c.codigo_nomina, c.nombre_completo
       ORDER BY c.nombre_completo`,
      [desde, hasta],
    );
    return { desde, hasta, colaboradores: rows };
  }

  @Get('gasto-empresa')
  @Roles('RRHH', 'ADMIN_EMPRESA', 'SUPERADMIN', 'SOPORTE')
  async gastoEmpresa(@Req() req: Request, @Query('desde') desdeQ?: string, @Query('hasta') hastaQ?: string) {
    const { desde, hasta } = this.rango(desdeQ, hastaQ);
    const esPlataforma = req.ambito!.tipo === 'PLATAFORMA';

    const { rows } = await req.dbClient!.query(
      `SELECT e.id, e.nombre,
              COUNT(DISTINCT p.colaborador_id) AS colaboradores_activos,
              COUNT(p.id) AS cantidad_pedidos,
              COALESCE(SUM(p.subsidio_empresa), 0) AS subsidio_total
       FROM empresa e
       LEFT JOIN pedido p ON p.empresa_id = e.id
         AND p.fecha_servicio BETWEEN $1 AND $2
         AND p.estado NOT IN ('CANCELADO', 'NO_ENTREGADO')
       ${esPlataforma ? '' : 'WHERE e.id = $3'}
       GROUP BY e.id, e.nombre
       ORDER BY e.nombre`,
      esPlataforma ? [desde, hasta] : [desde, hasta, req.ambito!.id],
    );
    return { desde, hasta, empresas: rows };
  }

  @Get('entregas-suplidor')
  @Roles('SUPLIDOR_ADMIN', 'SUPERADMIN', 'SOPORTE')
  async entregasSuplidor(@Req() req: Request, @Query('desde') desdeQ?: string, @Query('hasta') hastaQ?: string) {
    const { desde, hasta } = this.rango(desdeQ, hastaQ);
    const esPlataforma = req.ambito!.tipo === 'PLATAFORMA';

    const { rows } = await req.dbClient!.query(
      `SELECT s.id, s.nombre,
              COUNT(*) FILTER (WHERE p.estado = 'RECIBIDO') AS recibidos,
              COUNT(*) FILTER (WHERE p.estado = 'NO_ENTREGADO') AS no_entregados,
              COUNT(*) FILTER (WHERE p.estado = 'DISPUTA') AS en_disputa,
              COUNT(*) FILTER (WHERE p.estado = 'CANCELADO') AS cancelados,
              COUNT(*) AS total
       FROM suplidor s
       LEFT JOIN pedido p ON p.suplidor_id = s.id AND p.fecha_servicio BETWEEN $1 AND $2
       ${esPlataforma ? '' : 'WHERE s.id = $3'}
       GROUP BY s.id, s.nombre
       ORDER BY s.nombre`,
      esPlataforma ? [desde, hasta] : [desde, hasta, req.ambito!.id],
    );

    const suplidores = rows.map((r: Record<string, unknown>) => {
      const total = Number(r.total);
      const enDisputa = Number(r.en_disputa);
      return { ...r, tasaDisputasPct: total > 0 ? Math.round((enDisputa / total) * 10000) / 100 : 0 };
    });
    return { desde, hasta, suplidores };
  }

  @Get('disputas')
  @Roles('RRHH', 'ADMIN_EMPRESA', 'SUPERADMIN', 'SOPORTE')
  async disputas(@Req() req: Request, @Query('desde') desdeQ?: string, @Query('hasta') hastaQ?: string) {
    const { desde, hasta } = this.rango(desdeQ, hastaQ);
    const { rows } = await req.dbClient!.query(
      `SELECT motivo_disputa, resolucion_disputa, COUNT(*) AS cantidad
       FROM pedido
       WHERE disputado_en IS NOT NULL AND fecha_servicio BETWEEN $1 AND $2
       GROUP BY motivo_disputa, resolucion_disputa
       ORDER BY cantidad DESC`,
      [desde, hasta],
    );
    return { desde, hasta, disputas: rows };
  }

  private rango(desdeQ?: string, hastaQ?: string): { desde: string; hasta: string } {
    const hasta = hastaQ ?? iso(new Date());
    const desde = desdeQ ?? iso(new Date(Date.now() - 30 * 86400000));
    return { desde, hasta };
  }
}
