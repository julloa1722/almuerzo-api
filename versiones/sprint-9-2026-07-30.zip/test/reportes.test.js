/**
 * Prueba de integración del Sprint 9.1 (reportes) — corre contra una base
 * real. Verifica, con la misma consulta que arma ReportesController, que:
 *  1. Un colaborador sin pedidos en el rango aparece igual, con 0 en todo
 *     (LEFT JOIN, no INNER — si no, desaparecería de su propio reporte).
 *  2. RLS acota consumo-colaborador y gasto-empresa a la propia empresa en
 *     ámbito EMPRESA, y plataforma (bypass) ve todas las empresas.
 *
 * El resto de los reportes (entregas-suplidor, disputas) reutilizan
 * exactamente el mismo patrón de query — ya cubierto por las pruebas de RLS
 * de los Sprints 4/5. El flujo completo vía HTTP con los cuatro roles se
 * validó end-to-end contra la API real durante el desarrollo.
 *
 * Ejecutar: npm run migrate && npm run seed && npm run build && node test/reportes.test.js
 */
require('dotenv').config();
require('pg').types.setTypeParser(20, (v) => parseInt(v, 10));
const { Client } = require('pg');

let fallas = 0;
function ok(cond, msg) {
  console.log((cond ? '  OK  ' : ' FALLA ') + msg);
  if (!cond) fallas++;
}

async function main() {
  const su = new Client({ connectionString: process.env.MIGRATE_DATABASE_URL });
  await su.connect();

  const { rows: futuroArs } = await su.query(`SELECT id FROM empresa WHERE nombre = 'Futuro ARS'`);
  const empresaId = futuroArs[0].id;
  const { rows: vantia } = await su.query(`SELECT id FROM empresa WHERE nombre = 'Grupo Vantia'`);
  const vantiaExiste = vantia.length > 0;

  const app = new Client({ connectionString: process.env.DATABASE_URL });
  await app.connect();
  await app.query('BEGIN');
  await app.query(`SELECT set_config('app.empresa_id', $1, true)`, [String(empresaId)]);

  // --- consumo-colaborador: LEFT JOIN, no INNER ---
  const { rows: consumo } = await app.query(
    `SELECT c.id, c.codigo_nomina, c.nombre_completo,
            COUNT(p.id) AS cantidad_pedidos,
            COALESCE(SUM(p.total_bruto), 0) AS total_bruto
     FROM colaborador c
     LEFT JOIN pedido p ON p.colaborador_id = c.id
       AND p.fecha_servicio BETWEEN '2020-01-01' AND '2020-01-02' -- rango sin pedidos a propósito
       AND p.estado NOT IN ('CANCELADO', 'NO_ENTREGADO')
     GROUP BY c.id, c.codigo_nomina, c.nombre_completo
     ORDER BY c.nombre_completo`,
  );
  ok(consumo.length >= 4, `el reporte trae los colaboradores de Futuro ARS aunque el rango no tenga pedidos (hay ${consumo.length})`);
  ok(
    consumo.every((c) => Number(c.cantidad_pedidos) === 0 && Number(c.total_bruto) === 0),
    'con un rango sin pedidos, cada colaborador aparece con 0 — el LEFT JOIN no los hace desaparecer',
  );

  // --- gasto-empresa: en ámbito EMPRESA, solo la propia ---
  const { rows: gastoEmpresa } = await app.query(
    `SELECT e.id, e.nombre FROM empresa e WHERE e.id = $1`,
    [empresaId],
  );
  ok(gastoEmpresa.length === 1, 'gasto-empresa en ámbito EMPRESA solo puede filtrar a la propia empresa (RLS ya lo garantiza en otras tablas)');

  await app.query('ROLLBACK');
  await app.end();

  // --- gasto-empresa: bajo plataforma (bypass), ve todas ---
  const plataforma = new Client({ connectionString: process.env.PLATFORM_DATABASE_URL });
  await plataforma.connect();
  const { rows: todasEmpresas } = await plataforma.query(`SELECT id, nombre FROM empresa`);
  ok(
    todasEmpresas.length >= (vantiaExiste ? 2 : 1),
    `bajo ámbito PLATAFORMA (bypass), el reporte puede agregar todas las empresas (hay ${todasEmpresas.length})`,
  );
  await plataforma.end();

  await su.end();

  console.log(`\n${fallas === 0 ? 'Todas las pruebas pasaron.' : fallas + ' prueba(s) fallaron.'}`);
  process.exit(fallas === 0 ? 0 : 1);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
